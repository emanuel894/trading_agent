# <img src="https://github.com/nautechsystems/nautilus_trader/raw/develop/assets/nautilus-trader-logo.png" alt="NautilusTrader" width="500">

[![rustc](https://img.shields.io/crates/msrv/nautilus-core?color=ea7233&logo=rust&label=rustc)](https://crates.io/crates/nautilus-core)
[![crates.io](https://img.shields.io/crates/v/nautilus-core?logo=rust)](https://crates.io/crates/nautilus-core)
[![codspeed](https://img.shields.io/endpoint?url=https://codspeed.io/badge.json)](https://codspeed.io/nautechsystems/nautilus_trader)
![pythons](https://img.shields.io/pypi/pyversions/nautilus_trader)
![pypi-version](https://img.shields.io/pypi/v/nautilus_trader)
[![Downloads](https://img.shields.io/pepy/dt/nautilus-trader?color=blue)](https://pepy.tech/projects/nautilus-trader)
[![Discord](https://img.shields.io/badge/Discord-%235865F2.svg?logo=discord&logoColor=white)](https://discord.gg/NautilusTrader)

| Branch    | Version                                                                                                                                                                                                                     | Status                                                                                                                                                                                            |
| :-------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `master`  | [![version](https://img.shields.io/endpoint?url=https%3A%2F%2Fraw.githubusercontent.com%2Fnautechsystems%2Fnautilus_trader%2Fmaster%2Fversion.json)](https://packages.nautechsystems.io/simple/nautilus-trader/index.html)  | [![build](https://github.com/nautechsystems/nautilus_trader/actions/workflows/build.yml/badge.svg?branch=master)](https://github.com/nautechsystems/nautilus_trader/actions/workflows/build.yml)  |
| `nightly` | [![version](https://img.shields.io/endpoint?url=https%3A%2F%2Fraw.githubusercontent.com%2Fnautechsystems%2Fnautilus_trader%2Fnightly%2Fversion.json)](https://packages.nautechsystems.io/simple/nautilus-trader/index.html) | [![build](https://github.com/nautechsystems/nautilus_trader/actions/workflows/build.yml/badge.svg?branch=nightly)](https://github.com/nautechsystems/nautilus_trader/actions/workflows/build.yml) |
| `develop` | [![version](https://img.shields.io/endpoint?url=https%3A%2F%2Fraw.githubusercontent.com%2Fnautechsystems%2Fnautilus_trader%2Fdevelop%2Fversion.json)](https://packages.nautechsystems.io/simple/nautilus-trader/index.html) | [![build](https://github.com/nautechsystems/nautilus_trader/actions/workflows/build.yml/badge.svg?branch=develop)](https://github.com/nautechsystems/nautilus_trader/actions/workflows/build.yml) |

| Platform           | Rust   | Python    |
| :----------------- | :----- | :-------- |
| `Linux (x86_64)`   | 1.99.0 | 3.13-3.14 |
| `Linux (ARM64)`    | 1.99.0 | 3.13-3.14 |
| `macOS (ARM64)`    | 1.99.0 | 3.13-3.14 |
| `Windows (x86_64)` | 1.99.0 | 3.13-3.14 |

- **Docs**: <https://nautilustrader.io/docs/>
- **Website**: <https://nautilustrader.io>
- **Support**: [support@nautilustrader.io](mailto:support@nautilustrader.io)

## Introduction

NautilusTrader is an open-source, production-grade, Rust-native engine for multi-asset,
multi-venue trading systems.

The system spans research, deterministic simulation, and live execution within a single
event-driven architecture, with Python serving as the control plane for strategy logic,
configuration, and orchestration.

This separation provides the performance and safety of a compiled trading engine with
the flexibility of Python for system composition and strategy development.
Trading systems can also be written entirely in Rust for mission-critical workloads.

The same strategy and execution-algorithm code can run across backtest and live systems, reducing
deployment divergence. Live execution still introduces venue, transport, timing, persistence,
external-activity, and reconciliation behavior that a simulation may not reproduce. See
[Backtest and live differences](docs/concepts/live.md#backtest-and-live-differences).

NautilusTrader is asset-class-agnostic. Any venue with a REST API or WebSocket feed can be
integrated through modular adapters. Current integrations span crypto exchanges (CEX and
DEX), traditional markets (FX, equities, futures, options), and betting exchanges.

![nautilus-trader](https://github.com/nautechsystems/nautilus_trader/raw/develop/assets/nautilus-trader.png "nautilus-trader")

## Features

- **Fast**: Rust core with the [mimalloc](https://crates.io/crates/mimalloc) allocator and asynchronous networking using [tokio](https://crates.io/crates/tokio).
- **Reliable**: Type- and thread-safety backed by Rust, with optional Redis-backed state persistence.
- **Portable**: Runs on Linux, macOS, and Windows. Deploy using Docker.
- **Flexible**: Modular adapters integrate any REST API or WebSocket feed.
- **Advanced**: Time in force `IOC`, `FOK`, `GTC`, `GTD`, `DAY`, `AT_THE_OPEN`, `AT_THE_CLOSE`, advanced order types and conditional triggers. Execution instructions `post-only`, `reduce-only`, and icebergs. Contingency orders including `OCO`, `OUO`, `OTO`.
- **Customizable**: User-defined components, or assemble entire systems from scratch using the [cache](https://nautilustrader.io/docs/latest/concepts/cache) and [message bus](https://nautilustrader.io/docs/latest/concepts/message_bus).
- **Backtesting**: Multiple venues, instruments, and strategies simultaneously using historical quote tick, trade tick, bar, order book, and custom data with nanosecond resolution.
- **Live**: Identical strategy implementations between research and live deployment.
- **Multi-venue**: Run market-making and cross-venue strategies across multiple venues simultaneously.
- **AI Training**: Engine fast enough to train AI trading agents (RL/ES).

![nautilus](https://github.com/nautechsystems/nautilus_trader/raw/develop/assets/nautilus-art.png "nautilus")

> *nautilus - from ancient Greek 'sailor' and naus 'ship'.*
>
> *The nautilus shell consists of modular chambers with a growth factor which approximates a logarithmic spiral.
> The idea is that this can be translated to the aesthetics of design and architecture.*

## Why NautilusTrader?

Trading strategy research is often conducted in Python using vectorized approaches, while
production trading systems are implemented separately using event-driven architectures in
compiled languages.

NautilusTrader removes this separation.

A Rust-native core provides a deterministic event-driven runtime for both research and live
execution, while Python serves as the control plane. The same architecture, execution
semantics, and time model operate across both environments, allowing strategies to move
from research to production without reimplementation.

Python bindings are provided via [PyO3](https://pyo3.rs) for the Rust-native v2 runtime.
During the v2 transition, v1 receives only critical security backports on the `develop_v1` branch.
See the [v2 migration guide](https://github.com/nautechsystems/nautilus_trader/blob/develop/MIGRATION_V2.md) for migration steps and compatibility details.
No Rust toolchain is required to install prebuilt wheels.

This project makes the [Soundness Pledge](https://raphlinus.github.io/rust/2020/01/18/soundness-pledge.html):

> "The intent of this project is to be free of soundness bugs.
> The developers will do their best to avoid them, and welcome help in analyzing and fixing them."

> [!NOTE]
>
> **MSRV:** NautilusTrader relies heavily on improvements in the Rust language and compiler.
> As a result, the Minimum Supported Rust Version (MSRV) is generally equal to the latest stable release of Rust.

## Integrations

NautilusTrader is modularly designed to work with *adapters*, enabling connectivity to trading venues
and data providers by translating their raw APIs into a unified interface and normalized domain model.

The following integrations are available or planned; see [docs/integrations/](https://nautilustrader.io/docs/latest/integrations/) for details:

| Name                                                       | ID                    | Type                    | Status                                                  | Docs                                              |
| :--------------------------------------------------------- | :-------------------- | :---------------------- | :------------------------------------------------------ | :------------------------------------------------ |
| [AX Exchange](https://architect.exchange)                  | `AX`                  | Derivatives Exchange    | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/architect_ax.md)        |
| [Betfair](https://betfair.com)                             | `BETFAIR`             | Sports Betting Exchange | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/betfair.md)             |
| [Binance](https://binance.com)                             | `BINANCE`             | Crypto Exchange (CEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/binance.md)             |
| [Blockchain](docs/integrations/blockchain.md)              | `BLOCKCHAIN`          | DeFi Data Provider      | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/blockchain.md)          |
| [Bybit](https://www.bybit.com)                             | `BYBIT`               | Crypto Exchange (CEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/bybit.md)               |
| [CoinAPI](https://www.coinapi.io/?ref=nautilus)            | `COINAPI`             | Data Provider           | ![status](https://img.shields.io/badge/beta-yellow)     | [Guide](docs/integrations/coinapi.md)             |
| [Coinbase](https://coinbase.com)                           | `COINBASE`            | Crypto Exchange (CEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/coinbase.md)            |
| [Databento](https://databento.com)                         | `DATABENTO`           | Data Provider           | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/databento.md)           |
| [Deribit](https://www.deribit.com)                         | `DERIBIT`             | Crypto Exchange (CEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/deribit.md)             |
| [Derive](https://www.derive.xyz)                           | `DERIVE`              | Crypto Exchange (DEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/derive.md)              |
| [dYdX](https://dydx.trade)                                 | `DYDX`                | Crypto Exchange (DEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/dydx.md)                |
| [FinFeed](https://www.finfeedapi.com/?ref=nautilus)        | `FINFEED`             | Data Provider           | ![status](https://img.shields.io/badge/building-orange) | -                                                 |
| [Hyperliquid](https://hyperliquid.xyz)                     | `HYPERLIQUID`         | Crypto Exchange (DEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/hyperliquid.md)         |
| [Interactive Brokers](https://www.interactivebrokers.com)  | `INTERACTIVE_BROKERS` | Brokerage (multi-venue) | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/interactive_brokers.md) |
| [Kalshi](https://kalshi.com)                               | `KALSHI`              | Prediction Market (CEX) | ![status](https://img.shields.io/badge/building-orange) | -                                                 |
| [Kraken](https://kraken.com)                               | `KRAKEN`              | Crypto Exchange (CEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/kraken.md)              |
| [Lighter](https://lighter.xyz)                             | `LIGHTER`             | Crypto Exchange (DEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/lighter.md)             |
| [Lighter on Robinhood](https://robinhoodchain.lighter.xyz) | `LIGHTER_ROBINHOOD`   | Crypto Exchange (DEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/lighter.md)             |
| [OKX](https://okx.com)                                     | `OKX`                 | Crypto Exchange (CEX)   | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/okx.md)                 |
| [Polymarket](https://polymarket.com)                       | `POLYMARKET`          | Prediction Market (DEX) | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/polymarket.md)          |
| [Tardis](https://tardis.dev)                               | `TARDIS`              | Crypto Data Provider    | ![status](https://img.shields.io/badge/stable-green)    | [Guide](docs/integrations/tardis.md)              |

- **ID**: The default client ID for the integrations adapter clients.
- **Type**: The type of integration (often the venue type).

For Lighter on Robinhood, `LIGHTER_ROBINHOOD` is the venue and explicit client ID to register. The
shared Lighter factory keeps `LIGHTER` as its compatibility default.

### Status

- `planned`: Planned for future development.
- `building`: Under construction and likely not in a usable state.
- `beta`: Completed to a minimally working state and in a beta testing phase.
- `stable`: Stabilized feature set and API, the integration has been tested by both developers and users to a reasonable level (some bugs may still remain).

See the [Integrations](https://nautilustrader.io/docs/latest/integrations/) documentation for further details.

## Roadmap

The [Roadmap](https://github.com/nautechsystems/nautilus_trader/blob/develop/ROADMAP.md) outlines NautilusTrader's strategic direction.
Current priorities include stabilizing the Rust-native core, improving documentation, and enhancing code ergonomics.

The open-source project focuses on single-node backtesting and live trading for individual and small-team quantitative traders.
UI dashboards, distributed orchestration, and built-in AI/ML tooling are out of scope to maintain focus on the core engine and ecosystem sustainability.
Additional external integrations (such as databases, cloud services, and monitoring tools) are also out of scope
unless explicitly listed in the [open-source scope](https://github.com/nautechsystems/nautilus_trader/blob/develop/ROADMAP.md#open-source-scope).

New integration proposals within the open-source scope should start with an RFC issue to discuss suitability before submitting a PR.
See [Community-contributed integrations](https://github.com/nautechsystems/nautilus_trader/blob/develop/ROADMAP.md#community-contributed-integrations) for guidelines.

## Security

[![OpenSSF Scorecard](https://api.scorecard.dev/projects/github.com/nautechsystems/nautilus_trader/badge)](https://scorecard.dev/viewer/?uri=github.com/nautechsystems/nautilus_trader)

Security is a priority for the NautilusTrader project. We apply security controls across dependency selection,
development, builds, and releases.

- Rust dependencies come only from crates.io; lock files pin dependencies with cryptographic checksums.
- New dependency and tooling versions observe a publication cooldown before adoption.
- Third-party Python packages install from wheels only.
- `cargo-vet` audits Rust dependency provenance.
- `cargo-deny` enforces a license allow list compatible with `LGPL-3.0-only`.
- TLS and most runtime cryptography use AWS-LC through Rust's [aws-lc-rs](https://github.com/aws/aws-lc-rs).
- Ed25519 signing uses [ed25519-dalek](https://github.com/dalek-cryptography/curve25519-dalek).
- Gitleaks screens for secrets and Zizmor audits GitHub Actions at pre-commit.
- CODEOWNERS require review of critical infrastructure, dependency manifests, and lock files.
- Protected branches require signed commits and passing CI.
- CodeQL runs on release PRs to `master` and pushes to `nightly`.
- Audit-relevant PRs and daily audits run `cargo-audit`, `cargo-deny`, and `cargo-vet`.
- OSV Scanner and `pip-audit` also run on audit-relevant PRs and daily.
- `cargo-fuzz` targets cover selected adapter and signing surfaces.
- GitHub Actions are pinned to commit SHAs; hardened CI runners restrict network egress to an allow list.
- Python artifacts carry SLSA build provenance.
- Container images are Sigstore-signed with attested SPDX SBOMs.
- PyPI and crates.io use OIDC Trusted Publishing through a protected `release` environment.
- The `release` environment never runs PR or fork code.
- Release tags are immutable.

OpenSSF Scorecard provides an automated repository-health signal alongside manual review, CI hardening, and security audits.

### Reporting a vulnerability

Report privately through [GitHub Security Advisories](https://github.com/nautechsystems/nautilus_trader/security/advisories/new)
or email <security@nautechsystems.io> (PGP key available on request).

- We acknowledge reports within 48 hours and patch critical vulnerabilities within 30 days.
- We thank and credit reporters in the relevant advisory and release notes unless they prefer anonymity.

See the following for details:

- [Security Policy](SECURITY.md): scope, coordinated disclosure, and step-by-step release verification.
- [Security Architecture](docs/developer_guide/security.md): the release supply chain from build to publication.
- [Responsible Disclosure](https://nautilustrader.io/security/responsible-disclosure/): full disclosure policy.
- [Supply Chain Security](https://nautilustrader.io/security/supply-chain/): full supply chain policy.
- [CI/CD security](.github/OVERVIEW.md#security): GitHub Actions security controls.

## Versioning and releases

> [!WARNING]
>
> **NautilusTrader is still under active development**. Some features may be incomplete, and while
> the API is becoming more stable, breaking changes can occur between releases.
> We strive to document these changes in the release notes on a **best-effort basis**.

We aim to follow a **bi-weekly release schedule**, though experimental or larger features may cause delays.

### Branches

We aim to maintain a stable, passing build across all branches.

- `master`: Reflects the source code for the latest released version; recommended for production use.
- `nightly`: Daily snapshots of the `develop` branch for early testing; merged at **14:00 UTC** and as required.
- `develop`: Active development branch for contributors and feature work.

> [!NOTE]
>
> The v2 release-candidate line is the transition toward a **stable API for version 2.x**.
> Once this milestone is reached, we plan to implement a formal deprecation process for any API changes.
> This approach allows us to maintain a rapid development pace for now.

## Precision mode

NautilusTrader supports two precision modes for its core value types (`Price`, `Quantity`, `Money`),
which differ in their internal bit-width and maximum decimal precision.

- **High-precision**: 128-bit integers with up to 16 decimals of precision, and a larger value range.
- **Standard-precision**: 64-bit integers with up to 9 decimals of precision, and a smaller value range.

> [!NOTE]
>
> By default, the official Python wheels ship in high-precision (128-bit) mode on all supported platforms.
>
> For pure Rust crates, high-precision works on all platforms (including Windows) since Rust handles
> `i128`/`u128` via software emulation. The default is standard-precision unless you explicitly enable
> the `high-precision` feature flag.

See the [Installation Guide](https://nautilustrader.io/docs/latest/getting_started/installation) for further details.

**Rust feature flag**: To enable high-precision mode in Rust, add the `high-precision` feature to your Cargo.toml:

```toml
[dependencies]
nautilus-model = { version = "*", features = ["high-precision"] }
```

## Installation

We recommend using the latest supported version of Python and installing [nautilus_trader](https://pypi.org/project/nautilus_trader/) inside a virtual environment to isolate dependencies.

**There are two supported ways to install**:

1. Pre-built binary wheel from PyPI *or* the Nautech Systems package index.
2. Build from source.

> [!TIP]
>
> We highly recommend installing using the [uv](https://docs.astral.sh/uv) package manager with a "vanilla" CPython.
>
> Conda and other Python distributions *may* work but aren't officially supported.

### From PyPI

This repository and the [documentation](https://nautilustrader.io/docs/latest) cover v2. To install
the v2 release-candidate wheels from PyPI using Python's pip package manager:

```bash
pip install -U nautilus_trader --pre
```

The v2 release-candidate wheels use `2.0.0rcN` versions and are intended for community testing
before the final `2.0.0` release. We do not recommend using release candidates in production
environments, such as live trading controlling real capital.

The `--pre` flag is required until `2.0.0` is released. Without it, pip installs the latest stable
v1 wheel, whose Python API differs from the v2 documentation:

```bash
# Installs the latest stable v1 wheel, which cannot run the v2 documentation
pip install -U nautilus_trader
```

Install optional dependencies for interactive tearsheets and charts with the `visualization` extra:

```bash
pip install -U "nautilus_trader[visualization]" --pre
```

See the [Installation Guide](https://nautilustrader.io/docs/latest/getting_started/installation#extras) for details.

### From the Nautech Systems package index

The Nautech Systems package index (`packages.nautechsystems.io`) complies with [PEP-503](https://peps.python.org/pep-0503/) and hosts both stable and development binary wheels for `nautilus_trader`.
This enables users to install either the latest stable release or pre-release versions for testing.

#### Stable wheels

Stable wheels correspond to official releases of `nautilus_trader` on PyPI, and use standard
versioning. As on PyPI, the latest stable release is still on the 1.x line, whose Python API differs
from these v2 docs. This index also hosts development wheels, so `--pre` allows those versions too.
To install a specific 2.x release candidate, pin its version (`nautilus_trader==2.0.0rcN`).

To install the latest stable release:

```bash
pip install -U nautilus_trader --index-url=https://packages.nautechsystems.io/simple
```

> [!TIP]
>
> Use `--extra-index-url` instead of `--index-url` to search both PyPI and the Nautech Systems package index.
> Pip selects the best matching version across both indexes without giving either index priority.

#### Development wheels

The main package index publishes v2 development wheels from both the `nightly` and `develop`
branches, allowing users to test features and fixes ahead of stable releases.

This process also helps preserve compute resources and provides easy access to the exact binaries tested in CI pipelines,
while adhering to [PEP-440](https://peps.python.org/pep-0440/) versioning standards:

- `develop` wheels use the version suffix `.devYYYYMMDD+run`.
- `nightly` wheels use `.devYYYYMMDD` when the base version is already a pre-release, and
  `aYYYYMMDD` otherwise.

| Platform           | Develop | Nightly |
| :----------------- | :------ | :------ |
| `Linux (x86_64)`   | ✓       | ✓       |
| `Linux (ARM64)`    | -       | ✓       |
| `macOS (ARM64)`    | -       | ✓       |
| `Windows (x86_64)` | -       | ✓       |

> [!WARNING]
>
> We do not recommend using development wheels in production environments, such as live trading controlling real capital.

#### Installation commands

By default, pip will install the latest stable release. Adding the `--pre` flag ensures that pre-release versions, including development wheels, are considered.

To install the latest available pre-release (including development wheels):

```bash
pip install -U nautilus_trader --pre --index-url=https://packages.nautechsystems.io/simple
```

#### Available versions

You can view all available versions of `nautilus_trader` on the [package index](https://packages.nautechsystems.io/simple/nautilus-trader/index.html).

To programmatically fetch and list available versions:

```bash
curl -s https://packages.nautechsystems.io/simple/nautilus-trader/index.html | sed -n 's/.*<a href="\([^"]*\)".*/\1/p' | awk -F'#' '{print $1}' | sort
```

> [!IMPORTANT]
>
> On Linux, confirm your glibc version with `ldd --version` and ensure it reports **2.35** or newer before installing binary wheels.

#### Branch updates

- `develop` branch wheels (`.devYYYYMMDD+run`): Build and publish continuously with every merged commit.
- `nightly` branch wheels (`.devYYYYMMDD` or `aYYYYMMDD`): Build and publish daily when we
  automatically merge the `develop` branch at **14:00 UTC** (if there are changes).

#### Retention policies

- `develop` branch wheels: We retain only the most recent wheel build.
- `nightly` branch wheels: We retain only the 30 most recent publication dates per platform.

#### Verifying build provenance

All release artifacts published by the project carry cryptographic attestations
generated by the CI/CD pipeline:

- Python wheels and source distribution (PyPI, GitHub Releases, Nautech Systems package index): [SLSA](https://slsa.dev/) build provenance.
- Docker images (`ghcr.io/nautechsystems/nautilus_trader`, `ghcr.io/nautechsystems/jupyterlab`): keyless [cosign](https://github.com/sigstore/cosign) signatures plus SPDX SBOM attestations.

Both are issued via [Sigstore](https://www.sigstore.dev/) and bound to a specific
commit SHA, so verification ensures the artifact was produced by the official
NautilusTrader GitHub Actions workflow and has not been tampered with since.

For step-by-step verification commands, see [Verifying releases](SECURITY.md#verifying-releases) in `SECURITY.md`.

> [!IMPORTANT]
>
> Verification requires the [GitHub CLI](https://cli.github.com/) (`gh`) for Python artifacts
> and [cosign](https://github.com/sigstore/cosign) for Docker images.
> Development wheels from `develop` and `nightly` branches are also attested.

### From source

It's possible to install from source using pip if you first install the build dependencies as specified in the `pyproject.toml`.

1. Install [rustup](https://rustup.rs/) (the Rust toolchain installer):
   - Linux and macOS:

       ```bash
       curl https://sh.rustup.rs -sSf | sh
       ```

   - Windows:
       - Download and install [`rustup-init.exe`](https://win.rustup.rs/x86_64)
       - Install "Desktop development with C++" using [Build Tools for Visual Studio 2022](https://visualstudio.microsoft.com/visual-cpp-build-tools/)
   - Verify (any system):
       from a terminal session run: `rustc --version`

2. Enable `cargo` in the current shell:
   - Linux and macOS:

       ```bash
       source $HOME/.cargo/env
       ```

   - Windows:
     - Start a new PowerShell

3. Install [clang](https://clang.llvm.org/) (a C language frontend for LLVM):
   - Linux (also installs [lld](https://lld.llvm.org/), used as the Rust linker for faster builds):

       ```bash
       sudo apt-get install clang lld
       ```

   - macOS:

       ```bash
       xcode-select --install
       ```

   - Windows:
       1. Add Clang to your [Build Tools for Visual Studio 2022](https://visualstudio.microsoft.com/visual-cpp-build-tools/):
          - Start | Visual Studio Installer | Modify | C++ Clang tools for Windows (latest) = checked | Modify
       2. Enable `clang` in the current shell:

          ```powershell
          [System.Environment]::SetEnvironmentVariable('path', "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\x64\bin\;" + $env:Path,"User")
          ```

   - Verify (any system):
       from a terminal session run: `clang --version`

4. Install uv (see the [uv installation guide](https://docs.astral.sh/uv/getting-started/installation) for more details):

    - Linux and macOS:

        ```bash
        curl -LsSf https://astral.sh/uv/install.sh | sh
        ```

    - Windows (PowerShell):

        ```powershell
        irm https://astral.sh/uv/install.ps1 | iex
        ```

5. Clone the source with `git`, then sync its dependencies from the project root:

    ```bash
    git clone --branch develop --depth 1 https://github.com/nautechsystems/nautilus_trader
    cd nautilus_trader
    make sync
    ```

> [!NOTE]
>
> The `--depth 1` flag fetches just the latest commit for a faster, lightweight clone.

6. Use the uv project environment.

    The uv project environment lives at `python/.venv`, beside `python/pyproject.toml`. Run direct uv
    project commands from `python/` or pass `--project python` from the repository root.

    For PyO3 compilation on Linux and macOS, run these commands from the repository root after
    `make sync` in Bash or Zsh. For Fish commands, see the developer guide's
    [environment setup](docs/developer_guide/environment_setup.md#4-configure-environment-variables).
    Set `PYO3_PYTHON` in each shell to this checkout's `python/.venv/bin/python`; replace any saved
    export that still points to the root `.venv/bin/python`.

    ```bash
    # Set the Python executable path for PyO3
    export PYO3_PYTHON="$PWD/python/.venv/bin/python"

    # Linux only: Set the library path for the uv-managed Python runtime
    PYTHON_LIB_DIR="$("$PYO3_PYTHON" -c 'import sysconfig; print(sysconfig.get_config_var("LIBDIR"))')"
    export LD_LIBRARY_PATH="$PYTHON_LIB_DIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

    # Required for Rust tests when using uv-installed Python
    export PYTHONHOME="$("$PYO3_PYTHON" -c 'import sys; print(sys.base_prefix)')"
    ```

> [!NOTE]
>
> The `LD_LIBRARY_PATH` export is Linux-specific and not needed on macOS.
>
> The `PYTHONHOME` variable is required when running `make cargo-test` with a `uv`-installed Python.
> Without it, tests that depend on PyO3 may fail to locate the Python runtime.

7. Build and install NautilusTrader in release mode:

    ```bash
    make build
    ```

See the [Installation Guide](https://nautilustrader.io/docs/latest/getting_started/installation) for other options and further details.

## Redis

Using [Redis](https://redis.io) with NautilusTrader is **optional** and only required if configured as the backend for a
[cache](https://nautilustrader.io/docs/latest/concepts/cache) database or [message bus](https://nautilustrader.io/docs/latest/concepts/message_bus).
See the **Redis** section of the [Installation Guide](https://nautilustrader.io/docs/latest/getting_started/installation#redis) for further details.

## Makefile

A `Makefile` is provided to automate most installation and build tasks for development. Some of the targets include:

- `make install`: Installs in `release` build mode with all dependency groups and extras.
- `make install-debug`: Same as `make install` but with `debug` build mode.
- `make sync`: Installs Python dependencies without building the package.
- `make build`: Builds and installs the package in `release` mode (default).
- `make build-debug`: Builds and installs the package in `debug` mode.
- `make build-wheel`: Builds a wheel in `release` mode.
- `make cargo-test`: Runs all Rust crate tests using `cargo-nextest`.
- `make clean`: Deletes build artifacts, caches, and build directories.
- `make distclean`: **CAUTION** Removes all artifacts not in the git index when run with
  `FORCE=1`. This includes source files which have not been `git add`ed.
- `make docs`: Builds the Python documentation with Sphinx and the Rust documentation with Cargo.
- `make pre-commit`: Runs the pre-commit checks over all files.
- `make ruff`: Runs Ruff over all files using `python/pyproject.toml` (with autofix).
- `make pytest`: Runs all tests with `pytest`.
- `make cargo-ci-benches`: Builds the Rust benchmarks used by CI.
- `make cargo-codspeed-build`: Builds the Rust benchmark subset used for CodSpeed comparisons.

> [!TIP]
>
> Run `make help` for documentation on all available make targets.

> [!TIP]
>
> See the [crates/infrastructure/TESTS.md](https://github.com/nautechsystems/nautilus_trader/blob/develop/crates/infrastructure/TESTS.md) file for running the infrastructure integration tests.

## Examples

Indicators and strategies can be developed in Python or Rust. For performance and
latency-sensitive applications, we recommend Rust. Below are some examples:

- [indicator](https://github.com/nautechsystems/nautilus_trader/tree/develop/crates/indicators/src/) implementations exposed through PyO3.
- [backtest](https://github.com/nautechsystems/nautilus_trader/tree/develop/examples/backtest/) examples using a `BacktestEngine` directly.
- [EMA crossover backtest](https://github.com/nautechsystems/nautilus_trader/blob/develop/crates/backtest/examples/engine_ema_cross.rs) example written in Rust.

## Docker

Docker containers are built with the following variant tags:

- `nautilus_trader:latest` has the latest release version installed.
- `nautilus_trader:nightly` has the head of the `nightly` branch installed.
- `jupyterlab:latest` has the latest release version installed along with `jupyterlab` and an
  example backtest notebook with accompanying data.
- `jupyterlab:nightly` has the head of the `nightly` branch installed along with `jupyterlab` and an
  example backtest notebook with accompanying data.

You can pull the container images as follows:

```bash
docker pull ghcr.io/nautechsystems/<image_variant_tag> --platform linux/amd64
```

You can launch the backtest example container by running:

```bash
docker pull ghcr.io/nautechsystems/jupyterlab:nightly --platform linux/amd64
docker run -p 8888:8888 ghcr.io/nautechsystems/jupyterlab:nightly
```

Then open your browser at the following address:

```bash
http://127.0.0.1:8888/lab
```

> [!WARNING]
>
> Examples use `log_level="ERROR"` because Nautilus logging exceeds Jupyter's stdout rate limit,
> causing notebooks to hang at lower log levels.

## Development

We aim to provide the most pleasant developer experience possible for this hybrid Rust and Python codebase.
See the [Developer Guide](https://nautilustrader.io/docs/latest/developer_guide/) for helpful information.

[Nautilus Engineering](https://github.com/nautechsystems/nautilus_engineering) maintains the
engineering standards, lint configuration, pre-commit definitions, tool pins, and repository
checks shared across Nautilus projects. This repository vendors selected files at the revision
recorded in `.nautilus-engineering.lock`; project-specific policy and CI wiring remain local.

> [!TIP]
>
> Run `make build-debug` to compile after Rust changes for the most efficient development workflow.

After changes to PyO3 bindings, stub annotations, or wrapped Rust docs, regenerate the
generated Python artifacts from the repository root:

```bash
make py-stubs
```

Commit the generated `.pyi` files and PyO3 wrapper doc comments changed by this target. See
[Generated Python artifacts](docs/developer_guide/rust.md#generated-python-artifacts) for details.

### Testing with Rust

[cargo-nextest](https://nexte.st) is the standard Rust test runner for NautilusTrader.
Its key benefit is isolating each test in its own process, ensuring test reliability
by avoiding interference. See the [Rust testing guidance](docs/developer_guide/testing.md#rust-tests)
for details about full-suite support and the limits of plain `cargo test`.

You can install cargo-nextest by running:

```bash
cargo install cargo-nextest
```

> [!TIP]
>
> Run Rust tests with `make cargo-test`, which uses **cargo-nextest** with an efficient profile.

## Contributing

Thank you for considering a contribution to NautilusTrader. We welcome high-quality work that
improves the project. Before starting a substantial change, open an
[issue](https://github.com/nautechsystems/nautilus_trader/issues) to discuss the problem and approach
with the team. Small, self-contained fixes do not require prior agreement.

Before getting started, be sure to review the [open-source scope](https://github.com/nautechsystems/nautilus_trader/blob/develop/ROADMAP.md#open-source-scope) outlined in the project's roadmap to understand what's in and out of scope.

Once you're ready to start working on your contribution, make sure to follow the guidelines
outlined in the [CONTRIBUTING.md](https://github.com/nautechsystems/nautilus_trader/blob/develop/CONTRIBUTING.md) file. This includes signing a Contributor License Agreement (CLA)
to ensure that your contributions can be included in the project.

> [!NOTE]
>
> Pull requests should target the `develop` branch (the default branch). This is where new features and improvements are integrated before release.

Thank you again for your interest in NautilusTrader! We look forward to reviewing your contributions and working with you to improve the project.

## Community

Join our community of users and contributors on [Discord](https://discord.gg/NautilusTrader) to chat
and stay up-to-date with the latest announcements and features of NautilusTrader. Whether you're a
developer looking to contribute or just want to learn more about the platform, all are welcome on our Discord server.

Features and integrations excluded by the [open-source scope](https://github.com/nautechsystems/nautilus_trader/blob/develop/ROADMAP.md#out-of-scope)
are also out of scope for discussion across official NautilusTrader channels, including GitHub and Discord.
This includes "Show & Tell" posts about downstream implementations, even when no contribution is offered
and no support or upstream inclusion is requested. Correctness and performance reports about the core trading engine
remain welcome. Keep those reports focused on the core behavior.

> [!WARNING]
>
> NautilusTrader does not issue, promote, or endorse any cryptocurrency tokens. Any claims or communications suggesting otherwise are unauthorized and false.
>
> All official updates and communications from NautilusTrader will be shared exclusively through <https://nautilustrader.io>, our [GitHub](https://github.com/nautechsystems), our [Discord server](https://discord.gg/NautilusTrader), or our verified X (Twitter) account: [@NautilusTrader](https://x.com/NautilusTrader).
>
> If you encounter any suspicious activity, please report it to the appropriate platform and contact us at <info@nautechsystems.io>.

## License

The source code for NautilusTrader is available on GitHub under the [GNU Lesser General Public License v3.0](https://www.gnu.org/licenses/lgpl-3.0.en.html).
Contributions to the project are welcome and require the completion of a standard [Contributor License Agreement (CLA)](https://github.com/nautechsystems/nautilus_trader/blob/develop/CLA.md).

---

NautilusTrader™ is developed and maintained by Nautech Systems, a technology
company specializing in the development of high-performance trading systems.
For more information, visit <https://nautilustrader.io>.

Use of this software is subject to the [Disclaimer](https://nautilustrader.io/legal/disclaimer/).

© 2015-2026 Nautech Systems Pty Ltd. All rights reserved.

![nautechsystems](https://github.com/nautechsystems/nautilus_trader/raw/develop/assets/ns-logo.png "nautechsystems")
<img src="https://github.com/nautechsystems/nautilus_trader/raw/develop/assets/ferris.png" alt="Ferris" width="128">
