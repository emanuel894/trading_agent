/*
 * QUANTCONNECT.COM - Democratizing Finance, Empowering Individuals.
 * Lean Algorithmic Trading Engine v2.0. Copyright 2014 QuantConnect Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

using System;
using System.Linq;
using Alpaca.Markets;
using QuantConnect.Data;
using QuantConnect.Util;
using QuantConnect.Orders;
using QuantConnect.Logging;
using QuantConnect.Interfaces;
using QuantConnect.Lean.Engine.Results;
using QuantConnect.Securities;
using QuantConnect.Orders.Fees;
using System.Collections.Generic;
using AlpacaMarket = Alpaca.Markets;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using QuantConnect.Api;
using QuantConnect.Data.Market;
using System.IO;
using System.Net.NetworkInformation;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using QuantConnect.Configuration;
using QuantConnect.Brokerages.CrossZero;
using System.Collections.Concurrent;
using System.Threading;
using System.Runtime.CompilerServices;
using System.Net.Http;

[assembly: InternalsVisibleTo("QuantConnect.Brokerages.Alpaca.Tests")]

namespace QuantConnect.Brokerages.Alpaca
{
    [BrokerageFactory(typeof(AlpacaBrokerageFactory))]
    public partial class AlpacaBrokerage : Brokerage
    {
        private IDataAggregator _aggregator;

        private IOrderProvider _orderProvider;
        private ISecurityProvider _securityProvider;

        private EventBasedDataQueueHandlerSubscriptionManager _subscriptionManager;

        private ConcurrentDictionary<int, decimal> _orderIdToFillQuantity = new();

        /// <summary>
        /// Holds the legs of a combo order until Lean has sent all of them, because Alpaca takes them as one order.
        /// </summary>
        private readonly GroupOrderCacheManager _groupOrderCacheManager = new();

        private BrokerageConcurrentMessageHandler<ITradeUpdate> _messageHandler;
        private AlpacaBrokerageSymbolMapper _symbolMapper;

        private IAlpacaTradingClient _tradingClient;

        private IAlpacaDataClient _equityHistoricalDataClient;
        private IAlpacaCryptoDataClient _cryptoHistoricalDataClient;
        private IAlpacaOptionsDataClient _optionsHistoricalDataClient;

        private IAlpacaStreamingClient _orderStreamingClient;
        private AlpacaStreamingClientWrapper _equityStreamingClient;
        private AlpacaStreamingClientWrapper _optionsStreamingClient;
        private AlpacaStreamingClientWrapper _cryptoStreamingClient;

        private bool _isInitialized;
        private bool _connected;

        private readonly ManualResetEvent _reconnectionResetEvent = new(false);
        private readonly CancellationTokenSource _cancellationTokenSource = new();

        /// <summary>
        /// Signals when the order <c>trade_updates</c> stream is authorized and
        /// able to deliver fill events. Order operations wait on this so REST
        /// order placement cannot race a dead stream (issue #58).
        /// </summary>
        private readonly ManualResetEventSlim _orderStreamReadyEvent = new(initialState: false);

        /// <summary>
        /// Provides user-facing reason messages for specific trade events.
        /// Used when emitting order events.
        /// </summary>
        private static readonly Dictionary<TradeEvent, string> _tradeEventReason = new()
        {
            { TradeEvent.Expired,  "The order was canceled by the brokerage." }
        };

        /// <summary>
        /// Maps each brokerage order ID to a set of execution IDs, used to detect and skip duplicate trade updates.
        /// </summary>
        internal readonly Dictionary<Guid, HashSet<Guid>> _duplicationExecutionOrderIdByBrokerageOrderId = [];

        /// <summary>
        /// Tracks unsupported TimeInForce values detected during order conversion.
        /// This allows the system to issue a warning for each unsupported TIF only once,
        /// preventing duplicate messages when processing multiple orders.
        /// </summary>
        private readonly HashSet<AlpacaMarket.TimeInForce> _unsupportedTimeInForce = [];

        /// <summary>
        /// Tracks the Alpaca orders with an unsupported order class, so their warning is sent once per order
        /// instead of every time the open orders are read.
        /// </summary>
        private readonly HashSet<Guid> _unsupportedOrderClassOrderIds = [];

        /// <summary>
        /// Returns true if we're currently connected to the broker
        /// </summary>
        public override bool IsConnected => _connected;

        /// <summary>
        /// Enables concurrent order requests processing
        /// </summary>
        public override bool ConcurrencyEnabled => true;

        /// <summary>
        /// Parameterless constructor for brokerage
        /// </summary>
        public AlpacaBrokerage() : base("Alpaca")
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AlpacaBrokerage"/> class.
        /// </summary>
        /// <param name="apiKey">The API key for authentication with Alpaca.</param>
        /// <param name="apiKeySecret">The secret key for authentication with Alpaca.</param>
        /// <param name="isPaperTrading">Indicates whether the brokerage should use the paper trading environment.</param>
        /// <remarks>
        /// This constructor initializes a new instance of the <see cref="AlpacaBrokerage"/> class with the specified API key,
        /// API secret key, and a flag indicating whether to use paper trading. It also retrieves an instance of <see cref="IDataAggregator"/>
        /// from the <see cref="Composer"/>. This constructor is required for brokerages implementing <see cref="IDataQueueHandler"/>.
        /// </remarks>
        public AlpacaBrokerage(string apiKey, string apiKeySecret, string accessToken, bool isPaperTrading, IAlgorithm algorithm)
            : this(apiKey, apiKeySecret, accessToken, isPaperTrading, algorithm?.Portfolio?.Transactions, algorithm?.Portfolio)
        { }

        /// <summary>
        /// Initializes a new instance of the <see cref="AlpacaBrokerage"/> class.
        /// </summary>
        /// <param name="apiKey">The API key for authentication with Alpaca.</param>
        /// <param name="apiKeySecret">The secret key for authentication with Alpaca.</param>
        /// <param name="isPaperTrading">Indicates whether the brokerage should use the paper trading environment.</param>
        /// <param name="securityProvider">The type capable of fetching the holdings for the specified symbol</param>
        /// <remarks>
        /// This constructor initializes a new instance of the <see cref="AlpacaBrokerage"/> class with the specified API key,
        /// API secret key, a flag indicating whether to use paper trading, and an instance of <see cref="IDataAggregator"/>.
        /// </remarks>
        public AlpacaBrokerage(string apiKey, string apiKeySecret, string accessToken, bool isPaperTrading, IOrderProvider orderProvider, ISecurityProvider securityProvider) : base("Alpaca")
        {
            Initialize(apiKey, apiKeySecret, accessToken, isPaperTrading, orderProvider, securityProvider);
        }

        /// <summary>
        /// Initializes this instance
        /// </summary>
        private void Initialize(string apiKey, string apiKeySecret, string accessToken, bool isPaperTrading, IOrderProvider orderProvider, ISecurityProvider securityProvider)
        {
            if (_isInitialized)
            {
                return;
            }
            _isInitialized = true;
            ValidateSubscription();

            SecurityKey tradingSecretKey = null;
            if (!string.IsNullOrEmpty(accessToken))
            {
                tradingSecretKey = new OAuthKey(accessToken);
            }
            SecretKey secretKey = null;
            if (!string.IsNullOrEmpty(apiKeySecret))
            {
                secretKey = new SecretKey(apiKey, apiKeySecret);
            }

            if (secretKey == null && tradingSecretKey == null)
            {
                // shouldn't happen
                throw new ArgumentException("No valid Alpaca brokerage credentials were provided!");
            }

            _orderProvider = orderProvider;
            _securityProvider = securityProvider;

            var environment = isPaperTrading ? Environments.Paper : Environments.Live;
            // trading api client
            _tradingClient = EnvironmentExtensions.GetAlpacaTradingClient(environment, tradingSecretKey ?? secretKey);
            // order updates
            _orderStreamingClient = EnvironmentExtensions.GetAlpacaStreamingClient(environment, tradingSecretKey ?? secretKey);

            // if we are used as a data queue handler ignore order updates
            if (_orderProvider != null)
            {
                _orderStreamingClient.OnTradeUpdate += (message) => _messageHandler.HandleNewMessage(message);
                WireStreamingClientEvents(_orderStreamingClient);
            }
            _messageHandler = new(HandleTradeUpdate, ConcurrencyEnabled);
            _symbolMapper = new AlpacaBrokerageSymbolMapper(_tradingClient);

            // historical equity
            _equityHistoricalDataClient = EnvironmentExtensions.GetAlpacaDataClient(environment, tradingSecretKey ?? secretKey);

            // historical options
            _optionsHistoricalDataClient = EnvironmentExtensions.GetAlpacaOptionsDataClient(environment, tradingSecretKey ?? secretKey);

            // historical crypto
            _cryptoHistoricalDataClient = EnvironmentExtensions.GetAlpacaCryptoDataClient(environment, tradingSecretKey ?? secretKey);

            if (secretKey != null)
            {
                // equity streaming client
                _equityStreamingClient = new AlpacaStreamingClientWrapper(secretKey, SecurityType.Equity);

                // streaming crypto
                _cryptoStreamingClient = new AlpacaStreamingClientWrapper(secretKey, SecurityType.Crypto);

                // streaming options
                _optionsStreamingClient = new AlpacaStreamingClientWrapper(secretKey, SecurityType.Option);

                foreach (var streamingClient in new IStreamingClient[] { _cryptoStreamingClient, _optionsStreamingClient, _equityStreamingClient })
                {
                    WireStreamingClientEvents(streamingClient);
                }

                _subscriptionManager = new EventBasedDataQueueHandlerSubscriptionManager();
                _subscriptionManager.SubscribeImpl += (s, t) => Subscribe(s);
                _subscriptionManager.UnsubscribeImpl += (s, t) => Unsubscribe(s);

                _aggregator = Composer.Instance.GetPart<IDataAggregator>();
                if (_aggregator == null)
                {
                    // toolbox downloader case
                    var aggregatorName = Config.Get("data-aggregator", "QuantConnect.Lean.Engine.DataFeeds.AggregationManager");
                    Log.Trace($"AlpacaBrokerage.AlpacaBrokerage(): found no data aggregator instance, creating {aggregatorName}");
                    _aggregator = Composer.Instance.GetExportedValueByTypeName<IDataAggregator>(aggregatorName);
                }
            }
            ReconnectionLogic();

            DeploymentDetailsHelper.Add("alpaca-paper-trading", isPaperTrading.ToStringInvariant());
        }

        private void WireStreamingClientEvents(IStreamingClient streamingClient)
        {
            streamingClient.Connected += (obj) => StreamingClient_Connected(streamingClient, obj);
            streamingClient.OnWarning += (obj) => StreamingClient_OnWarning(streamingClient, obj);
            streamingClient.SocketOpened += () => StreamingClient_SocketOpened(streamingClient);
            streamingClient.SocketClosed += () => StreamingClient_SocketClosed(streamingClient);
            streamingClient.OnError += (obj) => StreamingClient_OnError(streamingClient, obj);

            if (streamingClient is AlpacaStreamingClientWrapper wrapper)
            {
                wrapper.EnviromentFailure += (message) => Log.Trace($"AlpacaBrokerage.Initialize(): {message}");
            }
        }

        private void StreamingClient_OnError(IStreamingClient client, Exception obj)
        {
            Log.Trace($"{nameof(StreamingClient_OnError)}({client.GetStreamingClientName()}): {obj}");
        }

        private void StreamingClient_SocketClosed(IStreamingClient client)
        {
            Log.Trace($"{nameof(StreamingClient_SocketClosed)}({client.GetStreamingClientName()}): SocketClosed");
            if (_connected)
            {
                // Order-stream-specific: gate PlaceOrder/UpdateOrder/CancelOrder while the stream is down.
                if (client == _orderStreamingClient)
                {
                    Log.Trace($"{nameof(StreamingClient_SocketClosed)}({client.GetStreamingClientName()}): order stream closed; blocking order operations until reconnect.");
                    _orderStreamReadyEvent.Reset();
                }
                _connected = false;
                // let consumers know, we will try to reconnect internally, if we can't lean will kill us
                OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Disconnect, "Disconnected", "Brokerage Disconnected"));
                _reconnectionResetEvent.Set();
            }
        }

        private void StreamingClient_SocketOpened(IStreamingClient client)
        {
            Log.Trace($"{nameof(StreamingClient_SocketOpened)}({client.GetStreamingClientName()}): SocketOpened");
        }

        private void StreamingClient_OnWarning(IStreamingClient client, string obj)
        {
            Log.Trace($"{nameof(StreamingClient_OnWarning)}({client.GetStreamingClientName()}): {obj}");
        }

        private void StreamingClient_Connected(IStreamingClient client, AuthStatus obj)
        {
            Log.Trace($"{nameof(StreamingClient_Connected)}({client.GetStreamingClientName()}): {obj}");

            if (client == _orderStreamingClient && obj == AuthStatus.Authorized)
            {
                Log.Trace($"{nameof(StreamingClient_Connected)}({client.GetStreamingClientName()}): order stream authorized; releasing order operations.");
                _orderStreamReadyEvent.Set();
            }
        }

        #region Brokerage

        /// <summary>
        /// Gets all open orders on the account.
        /// NOTE: The order objects returned do not have QC order IDs.
        /// </summary>
        /// <returns>The open orders returned from Alpaca</returns>
        public override List<Order> GetOpenOrders()
        {
            // the legs of advanced orders (bracket, oco, oto) come nested so we can tell how they relate to each other
            var orders = _tradingClient.ListOrdersAsync(new ListOrdersRequest() { OrderStatusFilter = OrderStatusFilter.Open, RollUpNestedOrders = true }).SynchronouslyAwaitTaskResult();

            var leanOrders = new List<Order>();
            foreach (var brokerageOrder in orders)
            {
                if (Log.DebuggingEnabled)
                {
                    Log.Debug($"{nameof(AlpacaBrokerage)}.{nameof(GetOpenOrders)}: {brokerageOrder}");
                }

                var legs = (brokerageOrder.Legs ?? []).Where(leg => IsOpen(leg.OrderStatus)).ToList();
                if (brokerageOrder.OrderClass == OrderClass.MultiLegOptions || legs.Count == 0)
                {
                    if (TryConvertToLeanOrders(brokerageOrder, out var convertedOrders))
                    {
                        leanOrders.AddRange(convertedOrders);
                    }
                    continue;
                }

                // best effort: rebuild the contingencies of the advanced order
                var parentOrders = default(List<Order>);
                var isParentOpen = IsOpen(brokerageOrder.OrderStatus) && TryConvertToLeanOrders(brokerageOrder, out parentOrders);
                var parentOrder = isParentOpen ? parentOrders[0] : null;
                var legOrders = new List<Order>();
                foreach (var leg in legs)
                {
                    if (TryConvertToLeanOrders(leg, out var convertedLegOrders))
                    {
                        legOrders.AddRange(convertedLegOrders);
                    }
                }

                if (isParentOpen)
                {
                    leanOrders.Add(parentOrder);
                }
                leanOrders.AddRange(legOrders);

                if (brokerageOrder.OrderClass == OrderClass.OneCancelsOther)
                {
                    // the take profit holds the stop loss as its leg
                    var members = isParentOpen ? legOrders.Append(parentOrder).ToList() : legOrders;
                    if (members.Count > 1)
                    {
                        OrderContingency.Relate(ContingencyType.OneCancelsOther, members);
                    }
                    continue;
                }

                if (isParentOpen)
                {
                    // held until the entry order fills, else they are working already
                    OrderContingency.Trigger([parentOrder], legOrders);
                }
                if (legOrders.Count > 1)
                {
                    OrderContingency.Relate(ContingencyType.OneCancelsOther, legOrders);
                }
            }

            return leanOrders;
        }

        /// <summary>
        /// Determines whether the brokerage order status is an open one, including the orders held until another fills
        /// </summary>
        internal static bool IsOpen(AlpacaMarket.OrderStatus orderStatus)
        {
            switch (orderStatus)
            {
                case AlpacaMarket.OrderStatus.Accepted:
                case AlpacaMarket.OrderStatus.New:
                case AlpacaMarket.OrderStatus.PartiallyFilled:
                case AlpacaMarket.OrderStatus.PendingNew:
                case AlpacaMarket.OrderStatus.AcceptedForBidding:
                case AlpacaMarket.OrderStatus.PendingReplace:
                case AlpacaMarket.OrderStatus.Held:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Converts an Alpaca order to the matching Lean orders: one order for a single order, one combo order per leg
        /// for a multi-leg options order. The combo orders share one <see cref="GroupOrderManager"/> and every one of them
        /// carries the id of the Alpaca order as its brokerage id, because Alpaca reports all legs under that id.
        /// Each order of an advanced order (bracket, oco, oto) converts to a single Lean order, its legs are not included.
        /// </summary>
        /// <param name="brokerageOrder">The Alpaca order.</param>
        /// <param name="leanOrders">When this method returns <c>true</c>, the Lean orders; otherwise <c>null</c>.</param>
        /// <returns><c>true</c> when the order was converted; otherwise <c>false</c>.</returns>
        private bool TryConvertToLeanOrders(IOrder brokerageOrder, out List<Order> leanOrders)
        {
            leanOrders = null;

            var orderProperties = new AlpacaOrderProperties();
            if (!orderProperties.TryGetLeanTimeInForceByAlpacaTimeInForce(brokerageOrder.TimeInForce))
            {
                if (_unsupportedTimeInForce.Add(brokerageOrder.TimeInForce))
                {
                    OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Warning, -1, $"Detected unsupported Lean TimeInForce of '{brokerageOrder.TimeInForce}', ignoring. Using default: TimeInForce.GoodTilCanceled"));
                }
            }

            switch (brokerageOrder.OrderClass)
            {
                case OrderClass.Simple:
                case OrderClass.Bracket:
                case OrderClass.OneCancelsOther:
                case OrderClass.OneTriggersOther:
                    leanOrders = [CreateLeanOrder(brokerageOrder, orderProperties)];
                    return true;
                case OrderClass.MultiLegOptions:
                    leanOrders = CreateComboLeanOrders(brokerageOrder, orderProperties);
                    return true;
                default:
                    if (_unsupportedOrderClassOrderIds.Add(brokerageOrder.OrderId))
                    {
                        OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Warning, "NotSupportedOrderType", $"The {brokerageOrder.OrderClass} order {brokerageOrder.OrderId} is not supported. Only simple, bracket, oco, oto and multi-leg option orders are supported."));
                    }
                    return false;
            }
        }

        /// <summary>
        /// Creates the Lean order of a single Alpaca order.
        /// </summary>
        /// <param name="brokerageOrder">The Alpaca order.</param>
        /// <param name="orderProperties">The order properties of the Lean order.</param>
        /// <returns>The Lean order, with its status and the id of the Alpaca order as its brokerage id.</returns>
        private Order CreateLeanOrder(IOrder brokerageOrder, AlpacaOrderProperties orderProperties)
        {
            var leanSymbol = _symbolMapper.GetLeanSymbol(brokerageOrder.AssetClass, brokerageOrder.Symbol);
            var quantity = brokerageOrder.OrderSide == OrderSide.Buy ? brokerageOrder.Quantity.Value : decimal.Negate(brokerageOrder.Quantity.Value);

            var leanOrder = default(Order);
            switch (brokerageOrder.OrderType)
            {
                case AlpacaMarket.OrderType.Market:

                    switch (brokerageOrder.TimeInForce)
                    {
                        case AlpacaMarket.TimeInForce.Opg:
                            leanOrder = new MarketOnOpenOrder(leanSymbol, quantity, brokerageOrder.SubmittedAtUtc.Value, properties: orderProperties);
                            break;
                        case AlpacaMarket.TimeInForce.Cls:
                            leanOrder = new MarketOnCloseOrder(leanSymbol, quantity, brokerageOrder.SubmittedAtUtc.Value, properties: orderProperties);
                            break;
                        default:
                            leanOrder = new Orders.MarketOrder(leanSymbol, quantity, brokerageOrder.SubmittedAtUtc.Value, properties: orderProperties);
                            break;
                    }
                    break;
                case AlpacaMarket.OrderType.Limit:
                    leanOrder = new Orders.LimitOrder(leanSymbol, quantity, brokerageOrder.LimitPrice.Value, brokerageOrder.SubmittedAtUtc.Value, properties: orderProperties);
                    break;
                case AlpacaMarket.OrderType.Stop:
                    leanOrder = new StopMarketOrder(leanSymbol, quantity, brokerageOrder.StopPrice.Value, brokerageOrder.SubmittedAtUtc.Value, properties: orderProperties);
                    break;
                case AlpacaMarket.OrderType.StopLimit:
                    leanOrder = new Orders.StopLimitOrder(leanSymbol, quantity, brokerageOrder.StopPrice.Value, brokerageOrder.LimitPrice.Value, brokerageOrder.SubmittedAtUtc.Value, properties: orderProperties);
                    break;
                case AlpacaMarket.OrderType.TrailingStop:
                    var trailingAsPercent = brokerageOrder.TrailOffsetInPercent.HasValue ? true : false;
                    var trailingAmount = brokerageOrder.TrailOffsetInPercent.HasValue ? brokerageOrder.TrailOffsetInPercent.Value / 100m : brokerageOrder.TrailOffsetInDollars.Value;
                    leanOrder = new Orders.TrailingStopOrder(leanSymbol, quantity, brokerageOrder.StopPrice.Value, trailingAmount, trailingAsPercent, brokerageOrder.SubmittedAtUtc.Value, properties: orderProperties);
                    break;
                default:
                    throw new NotSupportedException($"The Order type '{brokerageOrder.OrderType}' is not supported.");
            }

            leanOrder.Status = Orders.OrderStatus.Submitted;
            if (brokerageOrder.FilledQuantity > 0 && brokerageOrder.FilledQuantity != brokerageOrder.Quantity)
            {
                leanOrder.Status = Orders.OrderStatus.PartiallyFilled;
            }

            leanOrder.BrokerId.Add(brokerageOrder.OrderId.ToString());
            _duplicationExecutionOrderIdByBrokerageOrderId[brokerageOrder.OrderId] = [];

            return leanOrder;
        }

        /// <summary>
        /// Creates the Lean combo orders of an Alpaca multi-leg options order, one per leg, all sharing one
        /// <see cref="GroupOrderManager"/>. The symbol, the side and the quantities come from the leg; the order type,
        /// the price and the submit time come from the whole order, because a leg carries none of its own.
        /// </summary>
        /// <param name="brokerageOrder">The Alpaca multi-leg options order.</param>
        /// <param name="orderProperties">The order properties of the Lean orders.</param>
        /// <returns>One Lean combo order per leg, each with its status and the id of the Alpaca order as its brokerage id.</returns>
        private List<Order> CreateComboLeanOrders(IOrder brokerageOrder, AlpacaOrderProperties orderProperties)
        {
            // Alpaca marks a credit with a negative limit price; Lean marks it with a negative group quantity and keeps the price positive.
            var groupDirection = brokerageOrder.LimitPrice < 0 ? OrderDirection.Sell : OrderDirection.Buy;
            var groupQuantity = GroupOrderExtensions.GetGroupQuantityByEachLegQuantity(brokerageOrder.Legs.Select(leg => leg.Quantity.Value), groupDirection);

            var groupOrderManager = default(GroupOrderManager);
            switch (brokerageOrder.OrderType)
            {
                case AlpacaMarket.OrderType.Market:
                    groupOrderManager = new GroupOrderManager(brokerageOrder.Legs.Count, groupQuantity);
                    break;
                case AlpacaMarket.OrderType.Limit:
                    groupOrderManager = new GroupOrderManager(brokerageOrder.Legs.Count, groupQuantity, Math.Abs(brokerageOrder.LimitPrice.Value));
                    break;
                default:
                    throw new NotSupportedException($"The Order type '{brokerageOrder.OrderType}' is not supported for multi-leg orders.");
            }

            var leanOrders = new List<Order>(brokerageOrder.Legs.Count);
            foreach (var leg in brokerageOrder.Legs)
            {
                var leanSymbol = _symbolMapper.GetLeanSymbol(leg.AssetClass, leg.Symbol);
                // The side of the multi-leg order itself is not reliable, so the quantity takes its sign from the side of the leg.
                var quantity = leg.OrderSide == OrderSide.Buy ? leg.Quantity.Value : decimal.Negate(leg.Quantity.Value);

                var leanOrder = default(Order);
                if (brokerageOrder.OrderType == AlpacaMarket.OrderType.Market)
                {
                    leanOrder = new ComboMarketOrder(leanSymbol, quantity, brokerageOrder.SubmittedAtUtc.Value, groupOrderManager, properties: orderProperties);
                }
                else
                {
                    leanOrder = new ComboLimitOrder(leanSymbol, quantity, groupOrderManager.LimitPrice, brokerageOrder.SubmittedAtUtc.Value, groupOrderManager, properties: orderProperties);
                }

                leanOrder.Status = Orders.OrderStatus.Submitted;
                if (leg.FilledQuantity > 0 && leg.FilledQuantity != leg.Quantity)
                {
                    leanOrder.Status = Orders.OrderStatus.PartiallyFilled;
                }

                leanOrder.BrokerId.Add(brokerageOrder.OrderId.ToString());
                leanOrders.Add(leanOrder);
            }

            _duplicationExecutionOrderIdByBrokerageOrderId[brokerageOrder.OrderId] = [];

            return leanOrders;
        }

        /// <summary>
        /// Gets all holdings for the account
        /// </summary>
        /// <returns>The current holdings from the account</returns>
        public override List<Holding> GetAccountHoldings()
        {
            var positions = _tradingClient.ListPositionsAsync().SynchronouslyAwaitTaskResult();

            var holdings = new List<Holding>();
            foreach (var position in positions)
            {
                holdings.Add(new Holding()
                {
                    AveragePrice = position.AverageEntryPrice,
                    CurrencySymbol = Currencies.USD,
                    MarketValue = position.MarketValue ?? 0m,
                    MarketPrice = position.AssetCurrentPrice ?? 0m,
                    Quantity = position.Quantity,
                    Symbol = _symbolMapper.GetLeanSymbol(position.AssetClass, position.Symbol),
                    UnrealizedPnL = position.UnrealizedProfitLoss ?? 0m,
                    UnrealizedPnLPercent = position.UnrealizedProfitLossPercent ?? 0m,
                });
            }
            return holdings;
        }

        /// <summary>
        /// Gets the current cash balance for each currency held in the brokerage account
        /// </summary>
        /// <returns>The current cash balance for each currency available for trading</returns>
        public override List<CashAmount> GetCashBalance()
        {
            var accounts = _tradingClient.GetAccountAsync().SynchronouslyAwaitTaskResult();
            var balances = new List<CashAmount>() { new(accounts.TradableCash, accounts.Currency) };

            // Alpaca's account endpoint only reports fiat cash. Crypto coin balances are returned as
            // positions, but Lean's CashBook tracks each coin as a currency, so include them here.
            // Otherwise the daily cash sync would not find them and zero out the crypto holdings.
            var positions = _tradingClient.ListPositionsAsync().SynchronouslyAwaitTaskResult();
            foreach (var position in positions)
            {
                if (position.AssetClass != AssetClass.Crypto)
                {
                    continue;
                }

                var leanSymbol = _symbolMapper.GetLeanSymbol(position.AssetClass, position.Symbol);
                if (!CurrencyPairUtil.TryDecomposeCurrencyPair(leanSymbol, out var baseCurrency, out _))
                {
                    OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Error, -1, $"Unable to decompose crypto pair {leanSymbol} into base/quote currencies."));
                    continue;
                }
                balances.Add(new CashAmount(position.Quantity, baseCurrency));
            }

            return balances;
        }

        /// <summary>
        /// Places a new order and assigns a new broker ID to the order
        /// </summary>
        /// <param name="order">The order to be placed</param>
        /// <returns>True if the request for a new order has been placed, false otherwise</returns>
        public override bool PlaceOrder(Order order)
        {
            if (!CanSubscribe(order.Symbol))
            {
                OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Warning, -1, $"Symbol is not supported {order.Symbol}"));
                return false;
            }

            // Lean sends the legs of a combo one call at a time; nothing goes to Alpaca until the whole group is here.
            if (!_groupOrderCacheManager.TryGetGroupCachedOrders(order, out var orders))
            {
                return true;
            }

            if (orders.Count > 1)
            {
                return PlaceMultiLegOrder(orders);
            }

            if (order.Contingency != null)
            {
                // contingent orders are placed together, as a single advanced order (bracket, oco or oto), once they have all arrived
                if (ContingentOrderCache.TryGetContingentCachedOrders(order, out var contingentOrders))
                {
                    PlaceContingentOrders(contingentOrders);
                }
                return true;
            }

            try
            {
                ExecuteWhenReconnectedAndStreamLocked(nameof(PlaceOrder), () =>
                {
                    var holdingQuantity = _securityProvider.GetHoldingsQuantity(order.Symbol);
                    var isPlaceCrossOrder = TryCrossZeroPositionOrder(order, holdingQuantity);
                    if (isPlaceCrossOrder == null)
                    {
                        var orderRequest = order.CreateAlpacaOrder(order.AbsoluteQuantity, _symbolMapper, order.Type);
                        var response = _tradingClient.PostOrderAsync(orderRequest).SynchronouslyAwaitTaskResult();
                        if (response.OrderStatus == AlpacaMarket.OrderStatus.Rejected)
                        {
                            OnOrderEvent(new OrderEvent(order, DateTime.UtcNow, OrderFee.Zero, $"{nameof(AlpacaBrokerage)} Place Order Failed") { Status = Orders.OrderStatus.Invalid });
                            return;
                        }
                        order.BrokerId.Add(response.OrderId.ToString());

                        OnOrderEvent(new OrderEvent(order, DateTime.UtcNow, OrderFee.Zero, $"{nameof(AlpacaBrokerage)} Order Event") { Status = Orders.OrderStatus.Submitted });
                    }
                });
            }
            catch (Exception ex)
            {
                OnOrderEvent(new OrderEvent(order, DateTime.UtcNow, OrderFee.Zero, ex.Message) { Status = Orders.OrderStatus.Invalid });
            }
            return true;
        }

        /// <summary>
        /// Places the legs of a Lean combo order as one Alpaca multi-leg options order. Every leg gets the id of that
        /// Alpaca order as its brokerage id, because Alpaca cancels and replaces a multi-leg order only by that id.
        /// The request and the submitted events run inside the stream lock, so a fill cannot be handled before the legs carry the id.
        /// </summary>
        /// <param name="orders">The Lean combo orders, one per leg, all sharing one group order manager.</param>
        /// <returns>Always true; a rejected or failed request reaches Lean as Invalid order events, like a single order.</returns>
        private bool PlaceMultiLegOrder(List<Order> orders)
        {
            var orderRequest = orders.CreateAlpacaMultiLegOrder(_symbolMapper, _securityProvider);
            try
            {
                ExecuteWhenReconnectedAndStreamLocked(nameof(PlaceOrder), () =>
                {
                    var response = _tradingClient.PostOrderAsync(orderRequest).SynchronouslyAwaitTaskResult();

                    if (response.OrderStatus == AlpacaMarket.OrderStatus.Rejected)
                    {
                        OnOrderEvents(orders.CreateOrderEvents(Orders.OrderStatus.Invalid, $"Alpaca rejected the combo order {response.OrderId}"));
                        return;
                    }

                    var brokerageOrderId = response.OrderId.ToString();
                    var orderEvents = new List<OrderEvent>(orders.Count);
                    foreach (var order in orders)
                    {
                        order.BrokerId.Add(brokerageOrderId);
                        orderEvents.Add(new OrderEvent(order, DateTime.UtcNow, OrderFee.Zero)
                        {
                            Status = Orders.OrderStatus.Submitted
                        });
                    }

                    OnOrderEvents(orderEvents);
                });
            }
            catch (Exception ex)
            {
                OnOrderEvents(orders.CreateOrderEvents(Orders.OrderStatus.Invalid, ex.Message));
            }

            return true;
        }

        /// <summary>
        /// Places a set of contingent orders as a single advanced order:
        ///  - bracket: an entry order which triggers a take profit limit order and a stop loss order where one cancels the other
        ///  - oto: an entry order which triggers a take profit limit order or a stop loss order
        ///  - oco: a take profit limit order and a stop loss order where one cancels the other
        /// </summary>
        /// <param name="contingentOrders">All the orders of the set</param>
        private void PlaceContingentOrders(List<Order> contingentOrders)
        {
            try
            {
                ExecuteWhenReconnectedAndStreamLocked(nameof(PlaceOrder), () =>
                {
                    var entry = contingentOrders.SingleOrDefault(order => order.GetContingencyLink(ContingencyRole.Parent) != null);
                    var exits = contingentOrders.Where(order => order != entry).ToList();
                    var takeProfit = exits.SingleOrDefault(order => order.Type == Orders.OrderType.Limit) as Orders.LimitOrder;
                    var stopLoss = exits.SingleOrDefault(order => order.Type == Orders.OrderType.StopMarket || order.Type == Orders.OrderType.StopLimit);
                    if (takeProfit == null && stopLoss == null || exits.Count != (takeProfit == null ? 0 : 1) + (stopLoss == null ? 0 : 1)
                        || entry == null && (takeProfit == null || stopLoss == null))
                    {
                        throw new NotSupportedException("Unsupported set of contingent orders, expected a bracket, a one triggers other or a one cancels other.");
                    }

                    var stopLossStopPrice = (stopLoss as StopMarketOrder)?.StopPrice ?? (stopLoss as Orders.StopLimitOrder)?.StopPrice ?? 0;
                    var stopLossLimitPrice = (stopLoss as Orders.StopLimitOrder)?.LimitPrice;

                    // the base order is the entry, or the take profit for a one cancels other
                    var baseLeanOrder = entry ?? takeProfit;
                    var baseOrder = baseLeanOrder.CreateAlpacaOrder(baseLeanOrder.AbsoluteQuantity, _symbolMapper, baseLeanOrder.Type);

                    AlpacaMarket.OrderBase orderRequest;
                    if (entry == null)
                    {
                        var limitOrder = (AlpacaMarket.LimitOrder)baseOrder;
                        orderRequest = stopLossLimitPrice.HasValue
                            ? limitOrder.OneCancelsOther(stopLossStopPrice, stopLossLimitPrice.Value)
                            : limitOrder.OneCancelsOther(stopLossStopPrice);
                    }
                    else
                    {
                        var simpleOrder = baseOrder as AlpacaMarket.SimpleOrderBase
                            ?? throw new NotSupportedException($"The order type '{entry.Type}' can not trigger other orders.");
                        if (takeProfit != null && stopLoss != null)
                        {
                            orderRequest = stopLossLimitPrice.HasValue
                                ? simpleOrder.Bracket(takeProfit.LimitPrice, stopLossStopPrice, stopLossLimitPrice.Value)
                                : simpleOrder.Bracket(takeProfit.LimitPrice, stopLossStopPrice);
                        }
                        else if (takeProfit != null)
                        {
                            orderRequest = simpleOrder.TakeProfit(takeProfit.LimitPrice);
                        }
                        else
                        {
                            orderRequest = stopLossLimitPrice.HasValue
                                ? simpleOrder.StopLoss(stopLossStopPrice, stopLossLimitPrice.Value)
                                : simpleOrder.StopLoss(stopLossStopPrice);
                        }
                    }

                    // the advanced order overrides these values of its base order
                    orderRequest = orderRequest.WithLeanOrderSettings(baseLeanOrder);

                    var response = _tradingClient.PostOrderAsync(orderRequest).SynchronouslyAwaitTaskResult();
                    if (response == null || response.OrderStatus == AlpacaMarket.OrderStatus.Rejected)
                    {
                        throw new InvalidOperationException($"{nameof(AlpacaBrokerage)} Place Order Failed");
                    }

                    // the base order is the response itself, the rest come as its legs
                    var brokerageOrders = new List<(Order LeanOrder, IOrder BrokerageOrder)> { (baseLeanOrder, (IOrder)response) };
                    var legs = response.Legs ?? [];
                    foreach (var exit in exits.Where(order => order != baseLeanOrder))
                    {
                        var leg = legs.FirstOrDefault(x => exit.Type == Orders.OrderType.Limit
                            ? x.OrderType == AlpacaMarket.OrderType.Limit
                            : x.OrderType == AlpacaMarket.OrderType.Stop || x.OrderType == AlpacaMarket.OrderType.StopLimit);
                        if (leg == null)
                        {
                            // we can not track it: do not leave anything behind
                            _tradingClient.CancelOrderAsync(response.OrderId).SynchronouslyAwaitTaskResult();
                            throw new InvalidOperationException($"Failed to find the brokerage order of the {exit.Type} order in the response.");
                        }
                        brokerageOrders.Add((exit, leg));
                    }

                    foreach (var (leanOrder, brokerageOrder) in brokerageOrders)
                    {
                        leanOrder.BrokerId.Add(brokerageOrder.OrderId.ToString());
                        if (leanOrder.IsWaitingForTrigger())
                        {
                            // held orders do not get a new event until they are triggered, but they can be canceled before
                            _duplicationExecutionOrderIdByBrokerageOrderId.TryAdd(brokerageOrder.OrderId, []);
                        }
                    }

                    OnOrderEvents(contingentOrders.Select(order => new OrderEvent(order, DateTime.UtcNow, OrderFee.Zero, $"{nameof(AlpacaBrokerage)} Order Event")
                    {
                        Status = Orders.OrderStatus.Submitted
                    }).ToList());
                });
            }
            catch (Exception ex)
            {
                OnOrderEvents(contingentOrders.Select(order => new OrderEvent(order, DateTime.UtcNow, OrderFee.Zero, ex.Message)
                {
                    Status = Orders.OrderStatus.Invalid
                }).ToList());
            }
        }

        internal void HandleTradeUpdate(ITradeUpdate obj)
        {
            try
            {
                // TODO: Revert to Log.Debug when issue #28 is resolved
                Log.Trace($"{nameof(AlpacaBrokerage)}.{nameof(HandleTradeUpdate)}: {obj}");

                var brokerageOrderId = obj.Order.OrderId.ToString();
                var newLeanOrderStatus = GetOrderStatus(obj.Event);
                var leanOrders = default(List<Order>);
                if (TryGetOrRemoveCrossZeroOrder(brokerageOrderId, newLeanOrderStatus, out var crossZeroLeanOrder))
                {
                    leanOrders = [crossZeroLeanOrder];
                }
                else
                {
                    leanOrders = _orderProvider.GetOrdersByBrokerageId(brokerageOrderId);
                    if ((leanOrders == null || leanOrders.Count == 0) && TryConvertToLeanOrders(obj.Order, out leanOrders))
                    {
                        foreach (var leanOrder in leanOrders)
                        {
                            OnNewBrokerageOrderNotification(new(leanOrder));
                        }

                        if (leanOrders.All(leanOrder => leanOrder.Id != 0))
                        {
                            OnOrderEvents(leanOrders.CreateOrderEvents(Orders.OrderStatus.Submitted, "Order was submitted outside Lean"));

                            if (newLeanOrderStatus == Orders.OrderStatus.Submitted)
                            {
                                return;
                            }
                        }
                        else
                        {
                            leanOrders = null;
                        }
                    }
                }
                if (leanOrders == null || leanOrders.Count == 0)
                {
                    Log.Error($"{nameof(AlpacaBrokerage)}.{nameof(HandleTradeUpdate)}: order id not found: {obj.Order.OrderId}");
                    return;
                }

                // Alpaca can replay trade updates (new/fill) after a terminal event. Once the Lean
                // order is in a closed state, discard any further updates to avoid duplicate events.
                // A leg of a combo can be done while the others still wait, so only the open ones go on.
                for (var i = leanOrders.Count - 1; i >= 0; i--)
                {
                    if (IsClosed(leanOrders[i], newLeanOrderStatus, obj.Order.OrderId))
                    {
                        leanOrders.RemoveAt(i);
                    }
                }
                if (leanOrders.Count == 0)
                {
                    return;
                }

                // contingent orders are single orders, never the legs of a combo
                var contingentOrder = leanOrders[0];
                if (contingentOrder.Contingency != null && obj.Order.Quantity.HasValue && obj.Order.Quantity.Value != 0
                    && obj.Order.Quantity.Value != contingentOrder.AbsoluteQuantity)
                {
                    // the legs of advanced orders are sized by the brokerage, for example when the entry order gets partially filled and canceled
                    OnOrderUpdated(new OrderUpdateEvent { OrderId = contingentOrder.Id, Quantity = Math.Sign(contingentOrder.Quantity) * obj.Order.Quantity.Value });
                }

                switch (obj.Event)
                {
                    case TradeEvent.New:
                    case TradeEvent.PendingNew:
                        // we don't send anything for this event
                        _duplicationExecutionOrderIdByBrokerageOrderId.TryAdd(obj.Order.OrderId, []);
                        return;
                    case TradeEvent.Rejected:
                    case TradeEvent.Canceled:
                    case TradeEvent.Replaced:
                    case TradeEvent.Expired:
                        if (_duplicationExecutionOrderIdByBrokerageOrderId.Remove(obj.Order.OrderId))
                        {
                            if (newLeanOrderStatus == Orders.OrderStatus.UpdateSubmitted)
                            {
                                var replacedBrokerageOrderId = obj.Order.ReplacedByOrderId.Value;
                                // If the order already exists in the BrokerId list, it means the update was initiated by Lean.
                                // Otherwise, the order was updated outside of Lean and we need to notify about the new brokerage ID.
                                foreach (var leanOrder in leanOrders)
                                {
                                    if (!leanOrder.BrokerId.Contains(replacedBrokerageOrderId.ToString()))
                                    {
                                        OnOrderIdChangedEvent(new() { OrderId = leanOrder.Id, BrokerId = [replacedBrokerageOrderId.ToString()] });
                                    }
                                }
                                _duplicationExecutionOrderIdByBrokerageOrderId[replacedBrokerageOrderId] = [];
                            }

                            if (!_tradeEventReason.TryGetValue(obj.Event, out var message))
                            {
                                message = $"{nameof(AlpacaBrokerage)} Order Event";
                            }

                            OnOrderEvents(leanOrders.CreateOrderEvents(newLeanOrderStatus, message));
                        }
                        return;
                    case TradeEvent.Fill:
                        if (_duplicationExecutionOrderIdByBrokerageOrderId.Remove(obj.Order.OrderId))
                        {
                            break;
                        }
                        return;
                    case TradeEvent.PartialFill:
                        // A multi-leg update has no execution id; a replayed one is caught below by the unchanged filled quantity of its legs.
                        if (!obj.ExecutionId.HasValue || _duplicationExecutionOrderIdByBrokerageOrderId[obj.Order.OrderId].Add(obj.ExecutionId.Value))
                        {
                            break;
                        }
                        return;
                    case TradeEvent.Accepted:
                    case TradeEvent.PendingReplace:
                    case TradeEvent.PendingCancel:
                        // Skip this event to avoid flooding logs
                        return;
                    default:
                        Log.Trace($"{nameof(AlpacaBrokerage)}.{nameof(HandleTradeUpdate)}.Event: {obj.Event}. TradeUpdate: {obj}");
                        return;
                }

                // A multi-leg update carries the fills on its legs, a single order carries them on itself.
                var isMultiLegOrder = obj.Order.OrderClass == OrderClass.MultiLegOptions;
                IReadOnlyList<IOrder> legs = isMultiLegOrder ? obj.Order.Legs : [obj.Order];
                var orderEvents = new List<OrderEvent>(legs.Count);
                foreach (var leg in legs)
                {
                    var leanOrder = isMultiLegOrder ? leanOrders.Find(order => order.Symbol == _symbolMapper.GetLeanSymbol(leg.AssetClass, leg.Symbol)) : leanOrders[0];
                    if (leanOrder == null)
                    {
                        Log.Error($"{nameof(AlpacaBrokerage)}.{nameof(HandleTradeUpdate)}: no Lean order found for the leg '{leg.Symbol}' of the order {obj.Order.OrderId}");
                        continue;
                    }

                    // alpaca sends the accumulative filled quantity but we need the partial amount for our event
                    _orderIdToFillQuantity.TryGetValue(leanOrder.Id, out var previouslyFilledAmount);
                    var accumulativeFilledQuantity = _orderIdToFillQuantity[leanOrder.Id] =
                        leg.OrderSide == OrderSide.Buy ? leg.FilledQuantity : decimal.Negate(leg.FilledQuantity);

                    if (newLeanOrderStatus.IsClosed())
                    {
                        // cleanup
                        _orderIdToFillQuantity.TryRemove(leanOrder.Id, out _);
                    }

                    // A leg of the combo that did not trade this time, or a replayed update, brings nothing new.
                    if (isMultiLegOrder && newLeanOrderStatus == Orders.OrderStatus.PartiallyFilled && accumulativeFilledQuantity == previouslyFilledAmount)
                    {
                        continue;
                    }

                    var fee = new OrderFee(new CashAmount(0, Currencies.USD));
                    if (newLeanOrderStatus == Orders.OrderStatus.Filled)
                    {
                        var security = _securityProvider.GetSecurity(leanOrder.Symbol);
                        fee = security.FeeModel.GetOrderFee(new OrderFeeParameters(security, leanOrder));
                    }

                    orderEvents.Add(new OrderEvent(leanOrder, obj.TimestampUtc ?? DateTime.UtcNow, fee)
                    {
                        Status = newLeanOrderStatus,
                        FillPrice = isMultiLegOrder ? GetComboLegFillPrice(leg, leanOrder) : obj.Price ?? 0m,
                        FillQuantity = accumulativeFilledQuantity - previouslyFilledAmount,
                    });
                }

                if (orderEvents.Count == 0)
                {
                    return;
                }

                // if we filled the order and have another contingent order waiting, submit it
                if (!TryHandleRemainingCrossZeroOrder(leanOrders[0], orderEvents[0]))
                {
                    OnOrderEvents(orderEvents);

                    // contingent orders: the orders triggered by the one which filled are no longer held
                    OnContingentOrdersTriggered(orderEvents, _orderProvider);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, $"TradeUpdate: {obj}");
                throw;
            }
        }

        /// <summary>
        /// Checks whether the Lean order is closed for the trade update. A fill on a market-on-open or market-on-close
        /// order that Alpaca expired reopens the order instead, because the auction still filled it.
        /// </summary>
        /// <param name="leanOrder">The Lean order of the trade update.</param>
        /// <param name="newOrderStatus">The Lean order status of the trade update.</param>
        /// <param name="brokerageOrderId">The Alpaca order id of the trade update.</param>
        /// <returns>True when the trade update is skipped because the order is closed.</returns>
        private bool IsClosed(Order leanOrder, Orders.OrderStatus newOrderStatus, Guid brokerageOrderId)
        {
            if (!leanOrder.Status.IsClosed())
            {
                return false;
            }

            if (leanOrder.Status == Orders.OrderStatus.Canceled && newOrderStatus == Orders.OrderStatus.Filled
                && leanOrder.Type is Orders.OrderType.MarketOnOpen or Orders.OrderType.MarketOnClose)
            {
                return !TryReopenExpiredOrder(leanOrder, brokerageOrderId);
            }

            return true;
        }

        /// <summary>
        /// Reopens the order when Alpaca expired it, which the last Lean order event tells by its reason text.
        /// </summary>
        /// <param name="leanOrder">The Lean order of the trade update.</param>
        /// <param name="brokerageOrderId">The Alpaca order id of the trade update.</param>
        /// <returns>True when the order was canceled by an expired trade update and is reopened.</returns>
        private bool TryReopenExpiredOrder(Order leanOrder, Guid brokerageOrderId)
        {
            var orderEvents = _orderProvider.GetOrderTicket(leanOrder.Id)?.OrderEvents;
            if (orderEvents == null || orderEvents.Count == 0)
            {
                return false;
            }

            var expiredMessage = _tradeEventReason[TradeEvent.Expired];
            var lastOrderEventMessage = orderEvents[orderEvents.Count - 1].Message;
            if (string.Equals(lastOrderEventMessage, expiredMessage, StringComparison.Ordinal))
            {
                // the expired update dropped the order, the fill case needs it registered again
                _duplicationExecutionOrderIdByBrokerageOrderId.TryAdd(brokerageOrderId, []);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets the price of the contracts a combo leg filled since Lean last booked it. The leg carries the average price
        /// of everything it filled, so the price of the new quantity is what is left once the money Lean already booked
        /// is taken out of it. With no new quantity, Alpaca's average stays.
        /// </summary>
        /// <param name="leg">The Alpaca leg with its total filled quantity and average fill price.</param>
        /// <param name="leanOrder">The Lean order of the leg.</param>
        /// <returns>The fill price of the new quantity.</returns>
        private decimal GetComboLegFillPrice(IOrder leg, Order leanOrder)
        {
            // The ticket keeps a signed quantity, the Alpaca leg counts up from zero.
            var orderTicket = _orderProvider.GetOrderTicket(leanOrder.Id);
            var reportedQuantity = Math.Abs(orderTicket?.QuantityFilled ?? 0m);
            var newQuantity = leg.FilledQuantity - reportedQuantity;
            if (newQuantity <= 0)
            {
                return leg.AverageFillPrice.Value;
            }

            return (leg.FilledQuantity * leg.AverageFillPrice.Value - reportedQuantity * (orderTicket?.AverageFillPrice ?? 0m)) / newQuantity;
        }

        /// <summary>
        /// Updates the order with the same id
        /// </summary>
        /// <param name="order">The new order information</param>
        /// <returns>True if the request was made for the order to be updated, false otherwise</returns>
        public override bool UpdateOrder(Order order)
        {
            if (!_groupOrderCacheManager.TryGetGroupCachedOrders(order, out var orders))
            {
                return true;
            }

            if (!TryGetUpdateCrossZeroOrderQuantity(order, out var orderQuantity))
            {
                OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Warning, "UpdateOrderFailed", $"The quantity of the order {order.Id} cannot be changed because it crosses zero"));
                return false;
            }

            var brokerageOrderId = order.BrokerId.Last();
            var changeOrderRequest = order.CreateAlpacaChangeOrder(brokerageOrderId, orderQuantity);
            var isOrderUpdated = false;
            try
            {
                ExecuteWhenReconnectedAndStreamLocked(nameof(UpdateOrder), () =>
                {
                    var response = _tradingClient.PatchOrderAsync(changeOrderRequest).SynchronouslyAwaitTaskResult();
                    if (response.OrderStatus == AlpacaMarket.OrderStatus.Rejected)
                    {
                        // the replacing order is rejected when the order filled before it reached the venue, the fill is reported by the stream
                        OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Warning, "UpdateOrderFailed", $"Alpaca rejected the update of the order {order.Id} (BrokerId: {brokerageOrderId})"));
                        return;
                    }

                    var newBrokerageOrderId = response.OrderId.ToString();
                    foreach (var leanOrder in orders)
                    {
                        if (!leanOrder.BrokerId.Contains(newBrokerageOrderId))
                        {
                            leanOrder.BrokerId.Add(newBrokerageOrderId);
                        }
                    }

                    isOrderUpdated = true;
                });
                return isOrderUpdated;
            }
            catch (Exception ex)
            {
                // the request failed, the order is still working unchanged
                OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Warning, "UpdateOrderFailed", $"Failed to update the order {order.Id} (BrokerId: {brokerageOrderId}): {ex.Message}"));
                return false;
            }
        }

        /// <summary>
        /// Cancels the order with the specified ID
        /// </summary>
        /// <param name="order">The order to cancel</param>
        /// <returns>True if the request was made for the order to be canceled, false otherwise</returns>
        public override bool CancelOrder(Order order)
        {
            // The legs of a combo share one Alpaca order, so the cancel request goes out once, when Lean has asked to cancel every leg.
            if (!_groupOrderCacheManager.TryGetGroupCachedOrders(order, out var orders))
            {
                return true;
            }

            if (order.Status == Orders.OrderStatus.Filled)
            {
                OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Warning, -1, "Order already filled"));
                return false;
            }

            if (order.Status is Orders.OrderStatus.Canceled)
            {
                OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Warning, -1, "Order already canceled"));
                return false;
            }

            try
            {
                var response = false;
                ExecuteWhenReconnectedAndStreamLocked(nameof(CancelOrder), () =>
                {
                    var brokerageOrderId = new Guid(order.BrokerId.Last());
                    response = _tradingClient.CancelOrderAsync(brokerageOrderId).SynchronouslyAwaitTaskResult();
                });
                return response;
            }
            catch (Exception ex)
            {
                OnOrderEvents(orders.CreateOrderEvents(Orders.OrderStatus.Invalid, ex.Message));
                return false;
            }
        }

        /// <summary>
        /// Places an order that crosses zero (transitions from a short position to a long position or vice versa) and returns the response.
        /// This method implements brokerage-specific logic for placing such orders using Tradier brokerage.
        /// </summary>
        /// <param name="crossZeroOrderRequest">The request object containing details of the cross zero order to be placed.</param>
        /// <param name="isPlaceOrderWithLeanEvent">
        /// A boolean indicating whether the order should be placed with triggering a Lean event.
        /// Default is <c>true</c>, meaning Lean events will be triggered.
        /// </param>
        /// <returns>
        /// A <see cref="CrossZeroOrderResponse"/> object indicating the result of the order placement.
        /// </returns>
        protected override CrossZeroOrderResponse PlaceCrossZeroOrder(CrossZeroFirstOrderRequest crossZeroOrderRequest, bool isPlaceOrderWithLeanEvent)
        {
            var orderRequest = crossZeroOrderRequest.LeanOrder.CreateAlpacaOrder(crossZeroOrderRequest.AbsoluteOrderQuantity, _symbolMapper, crossZeroOrderRequest.OrderType);
            var response = _tradingClient.PostOrderAsync(orderRequest).SynchronouslyAwaitTaskResult();
            if (response.OrderStatus == AlpacaMarket.OrderStatus.Rejected)
            {
                return new CrossZeroOrderResponse(string.Empty, false);
            }

            var newBrokerageOrderId = response.OrderId.ToString();
            if (!crossZeroOrderRequest.LeanOrder.BrokerId.Contains(newBrokerageOrderId))
            {
                crossZeroOrderRequest.LeanOrder.BrokerId.Add(newBrokerageOrderId);
            }

            if (isPlaceOrderWithLeanEvent)
            {
                OnOrderEvent(new OrderEvent(crossZeroOrderRequest.LeanOrder, DateTime.UtcNow, OrderFee.Zero, $"{nameof(AlpacaBrokerage)} Order Event") { Status = Orders.OrderStatus.Submitted });
            }
            return new CrossZeroOrderResponse(newBrokerageOrderId, true);
        }

        /// <summary>
        /// Connects the client to the broker's remote servers
        /// </summary>
        public override void Connect()
        {
            if (_connected)
            {
                return;
            }

            ConnectAndAuthenticate(_orderStreamingClient);
            _connected = true;
        }

        /// <summary>
        /// Connects to the specified streaming client and authenticates synchronously.
        /// Throws <see cref="InvalidOperationException"/> if authentication fails.
        /// </summary>
        /// <param name="client">The streaming client to connect and authenticate.</param>
        private static void ConnectAndAuthenticate(IStreamingClient streamingClient)
        {
            if (streamingClient is AlpacaStreamingClientWrapper s && s.IsOpenAndAuthorized)
            {
                return;
            }

            var authorizedStatus = streamingClient.ConnectAndAuthenticateAsync().SynchronouslyAwaitTaskResult();
            if (authorizedStatus != AuthStatus.Authorized)
            {
                throw new InvalidOperationException($"Connect(): Failed to connect to {streamingClient.GetStreamingClientName()}. Status: {authorizedStatus}");
            }
        }

        /// <summary>
        /// Runs <paramref name="action"/> through <see cref="BrokerageConcurrentMessageHandler{T}.WithLockedStream"/>,
        /// but first waits for the order <c>trade_updates</c> stream to be authorized.
        /// Prevents REST order placement from racing a dead stream and losing
        /// subsequent fill events (issue #58).
        /// </summary>
        private void ExecuteWhenReconnectedAndStreamLocked(string methodName, Action action)
        {
            if (!_orderStreamReadyEvent.IsSet)
            {
                Log.Trace($"{nameof(AlpacaBrokerage)}.{nameof(ExecuteWhenReconnectedAndStreamLocked)}.{methodName}: waiting for order stream reconnect...");
                try
                {
                    if (!_orderStreamReadyEvent.Wait(TimeSpan.FromMinutes(10), _cancellationTokenSource.Token))
                    {
                        Log.Error($"{nameof(AlpacaBrokerage)}.{nameof(ExecuteWhenReconnectedAndStreamLocked)}.{methodName}: order stream not ready after 10 minutes; skipping {methodName}.");
                        return;
                    }
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                Log.Trace($"{nameof(AlpacaBrokerage)}.{nameof(ExecuteWhenReconnectedAndStreamLocked)}.{methodName}: order stream ready.");
            }
            _messageHandler.WithLockedStream(action);
        }

        private void ReconnectionLogic()
        {
            Task.Factory.StartNew(() =>
            {
                Log.Trace($"{nameof(AlpacaBrokerage)}.{nameof(ReconnectionLogic)}: Starting reconnection loop.");
                var attempt = 0;
                while (!_cancellationTokenSource.IsCancellationRequested)
                {
                    _reconnectionResetEvent.WaitOne(_cancellationTokenSource.Token);

                    var delay = TimeSpan.FromSeconds(5 * ++attempt);
                    Log.Trace($"{nameof(AlpacaBrokerage)}.{nameof(ReconnectionLogic)}: attempt #{attempt}, waiting {delay.TotalSeconds}s...");
                    // The server enforces a 90-second timeout for "partially dead" connections.
                    // If another WebSocket connection is opened with the same API key/secret
                    // before the old one is fully closed, this may trigger the
                    // "Too many connections" error. Waiting here prevents premature reconnection
                    // attempts that would conflict with the server's timeout window.
                    if (_cancellationTokenSource.Token.WaitHandle.WaitOne(delay))
                    {
                        break;
                    }

                    _reconnectionResetEvent.Reset();

                    try
                    {
                        Connect();

                        if (!IsConnected)
                        {
                            _reconnectionResetEvent.Set();
                        }
                        else
                        {
                            // if we are used as a brokerage ignore data queue handler updates
                            if (_subscriptionManager != null)
                            {
                                // resubscribe
                                var symbols = _subscriptionManager.GetSubscribedSymbols();
                                Unsubscribe(symbols);
                                Subscribe(symbols);
                            }
                            attempt = 0;
                            // let consumers know we are reconnected, avoid lean killing us
                            OnMessage(new BrokerageMessageEvent(BrokerageMessageType.Reconnect, "Reconnected", "Brokerage Reconnected"));
                        }
                    }
                    catch (Exception ex)
                    {
                        _reconnectionResetEvent.Set();
                        Log.Error(ex);
                    }
                }
                Log.Trace($"{nameof(AlpacaBrokerage)}.{nameof(ReconnectionLogic)}: Reconnection loop ended.");
                _reconnectionResetEvent?.DisposeSafely();
            }, _cancellationTokenSource.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        /// <summary>
        /// Disconnects the client from the broker's remote servers
        /// </summary>
        public override void Disconnect()
        {
            _orderStreamingClient?.DisconnectAsync()?.SynchronouslyAwaitTask();
            _equityStreamingClient?.DisconnectAsync()?.SynchronouslyAwaitTask();
            _cryptoStreamingClient?.DisconnectAsync()?.SynchronouslyAwaitTask();
            _optionsStreamingClient?.DisconnectAsync()?.SynchronouslyAwaitTask();
        }

        public override void Dispose()
        {
            _cancellationTokenSource?.Cancel();
            _cancellationTokenSource?.DisposeSafely();
            _orderStreamReadyEvent?.DisposeSafely();

            _tradingClient.DisposeSafely();

            _equityHistoricalDataClient.DisposeSafely();
            _cryptoHistoricalDataClient.DisposeSafely();
            _optionsHistoricalDataClient.DisposeSafely();

            // streaming
            _orderStreamingClient.DisposeSafely();
            _equityStreamingClient.DisposeSafely();
            _cryptoStreamingClient.DisposeSafely();
            _optionsStreamingClient.DisposeSafely();
        }

        /// <summary>
        /// Gets the latest market quote for the specified symbol.
        /// </summary>
        /// <param name="symbol">The symbol for which to get the latest quote.</param>
        /// <returns>The latest quote for the specified symbol.</returns>
        /// <exception cref="NotSupportedException">Thrown when the symbol's security type is not supported.</exception>
        /// <exception cref="Exception">Thrown when an error occurs while fetching the quote.</exception>
        protected IQuote GetLatestQuote(Symbol symbol)
        {
            var brokerageSymbol = _symbolMapper.GetBrokerageSymbol(symbol);
            switch (symbol.SecurityType)
            {
                case SecurityType.Equity:
                    return _equityHistoricalDataClient.GetLatestQuoteAsync(new LatestMarketDataRequest(brokerageSymbol)).SynchronouslyAwaitTaskResult();
                case SecurityType.Option:
                case SecurityType.IndexOption:
                    return _optionsHistoricalDataClient.ListLatestQuotesAsync(new LatestOptionsDataRequest(new string[] { brokerageSymbol })).SynchronouslyAwaitTaskResult()[brokerageSymbol];
                case SecurityType.Crypto:
                    return _cryptoHistoricalDataClient.ListLatestQuotesAsync(new LatestDataListRequest(new string[] { brokerageSymbol })).SynchronouslyAwaitTaskResult()[brokerageSymbol];
                default:
                    throw new NotSupportedException($"{nameof(AlpacaBrokerage)}.{nameof(GetLatestQuote)}: Security type {symbol.SecurityType} is not supported.");
            }
        }

        private static Orders.OrderStatus GetOrderStatus(TradeEvent tradeEvent)
        {
            switch (tradeEvent)
            {
                case TradeEvent.PendingNew:
                    return Orders.OrderStatus.New;
                case TradeEvent.New:
                    return Orders.OrderStatus.Submitted;
                case TradeEvent.Rejected:
                    return Orders.OrderStatus.Invalid;
                case TradeEvent.Canceled:
                    return Orders.OrderStatus.Canceled;
                case TradeEvent.Replaced:
                    return Orders.OrderStatus.UpdateSubmitted;
                case TradeEvent.Fill:
                    return Orders.OrderStatus.Filled;
                case TradeEvent.PartialFill:
                    return Orders.OrderStatus.PartiallyFilled;
                case TradeEvent.Expired:
                    return Orders.OrderStatus.Canceled;
                default:
                    return Orders.OrderStatus.New;
            }
        }

        #endregion

        private bool CanSubscribe(Symbol symbol)
        {
            if (symbol.Value.IndexOfInvariant("universe", true) != -1 || symbol.IsCanonical())
            {
                return false;
            }
            return _symbolMapper.SupportedSecurityType.Contains(symbol.SecurityType);
        }

        private class SubscriptionEntry
        {
            public Symbol Symbol { get; set; }
            public decimal PriceMagnifier { get; set; }
            public Tick LastTradeTick { get; set; }
            public Tick LastQuoteTick { get; set; }
            public Tick LastOpenInterestTick { get; set; }
        }

        private class ModulesReadLicenseRead : Api.RestResponse
        {
            [JsonProperty(PropertyName = "license")]
            public string License;
            [JsonProperty(PropertyName = "organizationId")]
            public string OrganizationId;
        }

        /// <summary>
        /// Validate the user of this project has permission to be using it via our web API.
        /// </summary>
        private static void ValidateSubscription()
        {
            try
            {
                var productId = 347;
                var userId = Globals.UserId;
                var token = Globals.UserToken;
                var organizationId = Globals.OrganizationID;
                // Verify we can authenticate with this user and token
                var api = new ApiConnection(userId, token);
                if (!api.Connected)
                {
                    throw new ArgumentException("Invalid api user id or token, cannot authenticate subscription.");
                }
                // Compile the information we want to send when validating
                var information = new Dictionary<string, object>()
                {
                    {"productId", productId},
                    {"machineName", Environment.MachineName},
                    {"userName", Environment.UserName},
                    {"domainName", Environment.UserDomainName},
                    {"os", Environment.OSVersion}
                };
                // IP and Mac Address Information
                try
                {
                    var interfaceDictionary = new List<Dictionary<string, object>>();
                    foreach (var nic in NetworkInterface.GetAllNetworkInterfaces().Where(nic => nic.OperationalStatus == OperationalStatus.Up))
                    {
                        var interfaceInformation = new Dictionary<string, object>();
                        // Get UnicastAddresses
                        var addresses = nic.GetIPProperties().UnicastAddresses
                            .Select(uniAddress => uniAddress.Address)
                            .Where(address => !IPAddress.IsLoopback(address)).Select(x => x.ToString());
                        // If this interface has non-loopback addresses, we will include it
                        if (!addresses.IsNullOrEmpty())
                        {
                            interfaceInformation.Add("unicastAddresses", addresses);
                            // Get MAC address
                            interfaceInformation.Add("MAC", nic.GetPhysicalAddress().ToString());
                            // Add Interface name
                            interfaceInformation.Add("name", nic.Name);
                            // Add these to our dictionary
                            interfaceDictionary.Add(interfaceInformation);
                        }
                    }
                    information.Add("networkInterfaces", interfaceDictionary);
                }
                catch (Exception)
                {
                    // NOP, not necessary to crash if fails to extract and add this information
                }
                // Include our OrganizationId is specified
                if (!string.IsNullOrEmpty(organizationId))
                {
                    information.Add("organizationId", organizationId);
                }
                // Create HTTP request
                using var request = ApiUtils.CreateJsonPostRequest("modules/license/read", information);
                api.TryRequest(request, out ModulesReadLicenseRead result);
                if (!result.Success)
                {
                    throw new InvalidOperationException($"Request for subscriptions from web failed, Response Errors : {string.Join(',', result.Errors)}");
                }

                var encryptedData = result.License;
                // Decrypt the data we received
                DateTime? expirationDate = null;
                long? stamp = null;
                bool? isValid = null;
                if (encryptedData != null)
                {
                    // Fetch the org id from the response if we are null, we need it to generate our validation key
                    if (string.IsNullOrEmpty(organizationId))
                    {
                        organizationId = result.OrganizationId;
                    }
                    // Create our combination key
                    var password = $"{token}-{organizationId}";
                    var key = SHA256.HashData(Encoding.UTF8.GetBytes(password));
                    // Split the data
                    var info = encryptedData.Split("::");
                    var buffer = Convert.FromBase64String(info[0]);
                    var iv = Convert.FromBase64String(info[1]);
                    // Decrypt our information
                    using var aes = new AesManaged();
                    var decryptor = aes.CreateDecryptor(key, iv);
                    using var memoryStream = new MemoryStream(buffer);
                    using var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
                    using var streamReader = new StreamReader(cryptoStream);
                    var decryptedData = streamReader.ReadToEnd();
                    if (!decryptedData.IsNullOrEmpty())
                    {
                        var jsonInfo = JsonConvert.DeserializeObject<JObject>(decryptedData);
                        expirationDate = jsonInfo["expiration"]?.Value<DateTime>();
                        isValid = jsonInfo["isValid"]?.Value<bool>();
                        stamp = jsonInfo["stamped"]?.Value<int>();
                    }
                }
                // Validate our conditions
                if (!expirationDate.HasValue || !isValid.HasValue || !stamp.HasValue)
                {
                    throw new InvalidOperationException("Failed to validate subscription.");
                }

                var nowUtc = DateTime.UtcNow;
                var timeSpan = nowUtc - Time.UnixTimeStampToDateTime(stamp.Value);
                if (timeSpan > TimeSpan.FromHours(12))
                {
                    throw new InvalidOperationException("Invalid API response.");
                }
                if (!isValid.Value)
                {
                    throw new ArgumentException($"Your subscription is not valid, please check your product subscriptions on our website.");
                }
                if (expirationDate < nowUtc)
                {
                    throw new ArgumentException($"Your subscription expired {expirationDate}, please renew in order to use this product.");
                }
            }
            catch (Exception e)
            {
                Log.Error($"ValidateSubscription(): Failed during validation, shutting down. Error : {e.Message}");
                Environment.Exit(1);
            }
        }
    }
}